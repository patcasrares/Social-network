package socialnetwork.domain.validators;

import socialnetwork.domain.Utilizator;

public class UtilizatorValidator implements Validator<Utilizator> {
    /*
    *verifica dacaun utilizator(entity) este valid
    * (numele si prenumele sunt siruri nevide de litere care incep cu litera mare)
    * arunca ValidationException in caz contrar
    *  */
    @Override
    public void validate(Utilizator entity) throws ValidationException {
        //TODO: implement method validate

        if(entity.getFirstName().equals(""))
            throw new ValidationException("firstName nu e vid");
        char ch='a';

        ch=entity.getFirstName().charAt(0);
        if(Character.isUpperCase(ch)==false)
            throw new ValidationException("firstName incepe cu uppercase");

        for(int i=1;i<entity.getFirstName().length();i++)
        {
            ch=entity.getFirstName().charAt(i);
            if(Character.isLowerCase(ch)==false)
                throw new ValidationException("firstName are restul lowercase letters");
        }

        if(entity.getLastName().equals(""))
            throw new ValidationException("lastName nu e vid");

        ch=entity.getLastName().charAt(0);
        if(Character.isUpperCase(ch)==false)
            throw new ValidationException("lastName incepe cu uppercase");

        for(int i=1;i<entity.getLastName().length();i++)
        {
            ch=entity.getLastName().charAt(i);
            if(Character.isLowerCase(ch)==false)
                throw new ValidationException("lastName are restul lowercase letters");
        }
    }
}
