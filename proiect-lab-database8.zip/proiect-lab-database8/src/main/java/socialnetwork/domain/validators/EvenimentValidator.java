package socialnetwork.domain.validators;

import socialnetwork.domain.Eveniment;
import socialnetwork.domain.Message;

import java.time.LocalDateTime;

public class EvenimentValidator implements Validator<Eveniment> {


    @Override
    public void validate(Eveniment entity) throws ValidationException {
        if(entity.getDescriere().length()==0)
            throw new ValidationException("tb descriere");

        LocalDateTime date = entity.getDate();
        if(date==null)
            throw new ValidationException("tb selectat data");
        LocalDateTime data2 = LocalDateTime.now();
        LocalDateTime data=LocalDateTime.of(data2.getYear(),data2.getMonth(),data2.getDayOfMonth(),14,00,00);

        if(data.compareTo(date)>=0)
            throw new ValidationException("cel mai devreme maine");


    }
}
