package socialnetwork.domain;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class PrietenDTO {
    private Utilizator utilizator;
    private LocalDateTime data;

    public PrietenDTO(Utilizator utilizator,LocalDateTime data)
    {
        this.utilizator = utilizator;
        this.data = data;
    }

    public String getDataP()
    {
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String str = data.format(format);
        return str;
    }

    public LocalDateTime getData()
    {
        return data;
    }

    public String getUsername(){return utilizator.getUsername();}

    @Override
    public String toString() {
        return ""+utilizator.getId()+" | "+utilizator.getFirstName()+" | "+
                utilizator.getLastName()+" | " + data.toString();
    }

}
