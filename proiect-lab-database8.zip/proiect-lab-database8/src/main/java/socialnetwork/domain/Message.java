package socialnetwork.domain;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Message extends Entity<Long> {
    private Utilizator from;
    private List<Utilizator> to=new ArrayList<Utilizator>();
    private String message;
    private LocalDateTime data;

    //private Message reply = null;

    public Message(Utilizator from,List<Utilizator> to,String message)
    {
        System.out.println("hgjkl");
        this.from=from;
        this.to=to;
        this.message=message;
        this.data=LocalDateTime.now();
    }

    public String getDataP()
    {
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String str = data.format(format);
        return str;
    }

    public String getUsername(){
        return from.getUsername();
    }

    public Utilizator getFrom()
    {
        return from;
    }

   /* public void setReply(Message reply)
    {
        this.reply=reply;
    }*/

    public Message getReply()
    {
        return null;
    }


    public Message(Utilizator from,List<Utilizator> to,String message,LocalDateTime data)
    {
        this.from=from;
        this.to=to;
        this.message=message;
        this.data=data;
    }

    public LocalDateTime getData()
    {
        return data;
    }


    public List<Utilizator> getTo()
    {
        return to;
    }

    public String getMessage()
    {
        return message;
    }


    @Override
    public String toString() {
        List<Long>lst=new ArrayList<Long>();
        for(Utilizator ut:to)
            lst.add(ut.getId());
        String msg=""+this.getId()+";"+from.getId()+";"+lst+";"+data+";"+message;
        /*if(reply ==  null)
            msg+=";0";
        else
            msg+=";"+reply.getId();*/
        return msg;
    }


    public void setTo(List<Utilizator> lst) {
        this.to = lst;
    }

    public void addTo(Utilizator ut) {
        to.add(ut);
    }

    public void setFrom(Utilizator from) {
        this.from = from;
    }
}
