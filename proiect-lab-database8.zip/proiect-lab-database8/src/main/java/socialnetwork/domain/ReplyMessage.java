package socialnetwork.domain;

import java.time.LocalDateTime;
import java.util.List;

public class ReplyMessage extends Message {

    private Message reply = null;
    public ReplyMessage(Utilizator from, List<Utilizator> to, String message)
    {
        super(from,to,message);

    }
    @Override
    public Message getReply()
    {
        return reply;
    }

    public ReplyMessage(Utilizator from, List<Utilizator> to, String message,LocalDateTime data)
    {
        super(from,to,message,data);

    }

    public void setReply(Message one) {
        this.reply=one;
    }
}
