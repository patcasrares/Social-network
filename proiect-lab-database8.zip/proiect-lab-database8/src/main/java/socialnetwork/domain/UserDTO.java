package socialnetwork.domain;

public class UserDTO {
    private Utilizator user;
    private String status = "Trimite cerere";

    public UserDTO(Utilizator user)
    {
        this.user = user;
    }

    public String getUsername()
    {
        return user.getUsername();
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String s)
    {
        status = s;
    }

    public Utilizator getUser() {
        return user;
    }

    public Long getId() {
        return user.getId();
    }
}
