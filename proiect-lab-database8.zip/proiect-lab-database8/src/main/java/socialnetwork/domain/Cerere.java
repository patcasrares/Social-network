package socialnetwork.domain;

import javafx.scene.control.Button;
import java.time.LocalDateTime;

public class Cerere extends Entity<Tuple<Long,Long>> {

    private String status="pending";
    private LocalDateTime date;
    private Button AcceptButton;
    private Button RejectButton;
    private Button RemoveButton;

    public Button getAcceptButton() {
        return AcceptButton;
    }

    public Button getRemoveButton() {
        return RemoveButton;
    }

    public void setAcceptButton(Button acceptButton) {
        AcceptButton = acceptButton;
    }

    public Button getRejectButton() {
        return RejectButton;
    }

    public void setRejectButton(Button rejectButton) {
        RejectButton = rejectButton;
    }


    public Cerere(Long id1,Long id2) {
        setId(new Tuple(id1,id2));
        date = LocalDateTime.now();
        AcceptButton = new Button("Accept");
        RejectButton = new Button("Reject");
        RemoveButton = new Button("Remove");
    }

    public LocalDateTime getDate()
    {
        return date;
    }
    public void setStatus(String status)
    {
        this.status=status;
    }

    public Long getSender()
    {
        return getId().getLeft();
    }

    public Long getRecv()
    {
        return getId().getRight();
    }

    public String getStatus(){return status;}

    public void setDate(LocalDateTime date) {
        this.date=date;
    }
}
