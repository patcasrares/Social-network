package socialnetwork.domain;

import javafx.scene.control.Button;

import java.time.LocalDateTime;

public class Eveniment extends Entity<Long> {
    private String descriere;
    private LocalDateTime date;
    private Button abonare;

    public Button getAbonare()
    {
        return abonare;
    }

    public Eveniment(String descriere,LocalDateTime date)
    {
        this.descriere = descriere;
        this.date = date;
        this.abonare = new Button("Abonare");
    }

    public String getDescriere()
    {
        return descriere;
    }

    public LocalDateTime getDate()
    {
        return date;
    }
}
