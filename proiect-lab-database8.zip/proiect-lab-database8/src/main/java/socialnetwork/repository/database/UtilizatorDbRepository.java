package socialnetwork.repository.database;

import socialnetwork.domain.Utilizator;
import socialnetwork.domain.validators.Validator;
import socialnetwork.repository.RepoException;
import socialnetwork.repository.Repository;

import java.sql.*;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;


public class UtilizatorDbRepository implements Repository<Long, Utilizator> {
    //Map<Long,Utilizator> entities=null;
    private String url;
    private String username;
    private String password;
    private Validator<Utilizator> validator;
    private static final String INSERT_USERS_SQL = "INSERT INTO users" +
            "  (id, nume, prenume,username,email,password) VALUES " +
            " (?, ?, ?,?,?,?);";

    private String cauta="select * from users "+"where id=?";

    private static final String DELETE_USERS_SQL = "DELETE FROM users WHERE ID = ? ";

    public UtilizatorDbRepository(String url, String username, String password, Validator<Utilizator> validator)
           // throws ParseException
    {

        this.url = url;
        this.username = username;
        this.password = password;
        this.validator = validator;
        findAll();

    }

    //gaseste utilizatorul cu acel id

    public Utilizator findOne2(Long aLong)
    {
        String cauta2="select * from prieteni where stanga=? or dreapta=?";
        Utilizator utilizator=null;
        try (Connection connection = DriverManager.getConnection(url, username, password);
             )
              {
                  PreparedStatement statement = connection.prepareStatement(cauta);
                  statement.setInt(1, aLong.intValue());
                  ResultSet resultSet = statement.executeQuery();
                  while (resultSet.next()) {
                        Long id = resultSet.getLong("id");
                        String firstName = resultSet.getString("nume");
                        String lastName = resultSet.getString("prenume");
                        String email =resultSet.getString("email");
                        String username =resultSet.getString("username");
                        String password =resultSet.getString("password");
                        utilizator = new Utilizator(firstName, lastName);
                        utilizator.setEmail(email);
                        utilizator.setUsername(username);
                        utilizator.setPassword(password);

                        utilizator.setId(id);

                  }


            //return users;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return utilizator;
    }


    public Long findByUsername(String user)
    {
        String cautId="select * from users "+"where username=?";
        return findByMailOrUsername(cautId,user);
    }

    @Override
    public Long findByEmail(String email)
    {
        String cautId="select * from users "+"where email=?";
        return findByMailOrUsername(cautId,email);

    }

    public Long findByMailOrUsername(String cautId,String element)
    {
        try (Connection connection = DriverManager.getConnection(url, username, password);
        )
        {
            PreparedStatement statement = connection.prepareStatement(cautId);
            statement.setString(1, element);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                Long id = resultSet.getLong("id");
                return id;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    @Override
    public Utilizator findOne(Long aLong)
    {
        String cauta2="select * from prieteni where stanga=? or dreapta=?";
        Utilizator utilizator=null;
        try (Connection connection = DriverManager.getConnection(url, username, password);
        )
        {
            utilizator=findOne2(aLong);
            if(utilizator==null)
                return null;

            PreparedStatement statement = connection.prepareStatement(cauta2);
            statement.setInt(1, aLong.intValue());
            statement.setInt(2, aLong.intValue());
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Long id1 = resultSet.getLong("stanga");
                Long id2 = resultSet.getLong("dreapta");
                Long g=id1;
                if(aLong.equals(id1))
                    g=id2;
                utilizator.addFriend(findOne2(g));

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return utilizator;
    }

    @Override
    public Iterable<Utilizator> findAll() {
        Map<Long,Utilizator> entities=new HashMap<Long,Utilizator>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement("SELECT * from users");
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String firstName = resultSet.getString("nume");
                String lastName = resultSet.getString("prenume");

                Utilizator utilizator = new Utilizator(firstName, lastName);
                utilizator.setId(id);
                entities.put(id,utilizator);
                entities.put(id,utilizator);
            }
            return entities.values();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return entities.values();
    }

    /*
    * salveaza un utilizator(entity) arunca Databse Exception daca este deja
    * */
    @Override
    public Utilizator save(Utilizator entity)throws DatabaseException {

        if(findOne(entity.getId())!=null)
        {
            throw new DatabaseException("este deja acest id");
        }

        if(findByEmail(entity.getEmail())!=null)
        {
            throw new DatabaseException("mail");
        }

        if(findByUsername(entity.getUsername())!=null)
        {
            throw new DatabaseException("username");
        }

        int A=entity.getId().intValue();
        String B=entity.getFirstName();
        String C=entity.getLastName();

        try (Connection connection = DriverManager.getConnection(url, username, password);

             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
            preparedStatement.setInt(1, A);
            preparedStatement.setString(2, B);
            preparedStatement.setString(3, C);

            preparedStatement.setString(4, entity.getUsername());
            preparedStatement.setString(5, entity.getEmail());
            preparedStatement.setString(6, entity.getPassword());

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }
        return null;
    }

    /*
    *id Long
    * sterge un utilizator ci Id-ul id
    * arunca exceptie RepoException daca nu este un astfel de utilizator
    * */
    @Override
    public Utilizator delete(Long id) throws DatabaseException {
        if(findOne(id)==null)
            throw new DatabaseException("nu este acest id");
        Utilizator ret=findOne(id);

        int A=id.intValue();
        try (Connection connection = DriverManager.getConnection(url, username, password);

             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_USERS_SQL)) {
            preparedStatement.setInt(1, A);

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }
        return ret;
    }

    @Override
    public Utilizator update(Utilizator entity) {
        throw new UnsupportedOperationException();
    }

    public List<Utilizator> findAllP(int pag,int count,String str)
    {
        System.out.println(str);
        pag++;
        System.out.println("pagina este DB  "+pag);
        int st=(pag-1)*count+1;
        int dr=st+count-1;

       // String str = "select * from users  LIMIT ? OFFSET  ?";
        List<Utilizator> lst = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement(str))
        {
            statement.setInt(1,count);
            statement.setInt(2,st-1);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Long id = resultSet.getLong("id");
                String firstName = resultSet.getString("nume");
                String lastName = resultSet.getString("prenume");
                String username = resultSet.getString("username");

                Utilizator utilizator = new Utilizator(firstName, lastName);
                utilizator.setId(id);
                utilizator.setUsername(username);
                lst.add(utilizator);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lst;
    }

    public List<Utilizator> findAll(int pag,int count) {


        String str = "select * from users  LIMIT ? OFFSET  ?";
        return findAllP(pag,count,str);
    }

    public int findCountP(String str) {
        //String str = "Select Count(*) from users";
        System.out.println(str);
        int ret=0;
        try (Connection connection = DriverManager.getConnection(url, username, password);

             PreparedStatement preparedStatement = connection.prepareStatement(str)) {
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next())
            {
                ret= resultSet.getInt(1);
            }

        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }
        return ret;
    }

    public int findCount() {

        String str = "Select Count(*) from users";
        return findCountP(str);

    }

    public int findCount(String firstName, String lastName) {
        String str = "select Count(*) from users ";
        if(firstName.length()>0 || lastName.length()>0)
            str+=" where ";
        if(firstName.length()>0)
            str += " nume like '"+firstName+"%' ";
        if(firstName.length()>0&&lastName.length()>0)
            str+="and ";
        if(firstName.length()>0&&lastName.length()>0)
            str+="prenume like '"+lastName+"%'";
        str+= " LIMIT ? OFFSET  ?";
        //str+= " LIMIT ? OFFSET  ?";
        int nr=findCountP(str);
        return nr;
    }

    public List<Utilizator> findAll(int index, int count, String firstName, String lastName) {
        String str = "select * from users ";
        if(firstName.length()>0 || lastName.length()>0)
            str+=" where ";
        if(firstName.length()>0)
            str += " nume like '"+firstName+"%' ";
        if(firstName.length()>0&&lastName.length()>0)
            str+="and ";
        if(firstName.length()>0&&lastName.length()>0)
            str+="prenume like '"+lastName+"%'";
        str+= " LIMIT ? OFFSET  ?";
        return findAllP(index,count,str);
    }

    public List<Utilizator> findAll(int index, int count, String username) {
        String str = "select * from users ";
        //if(firstName.length()>0 || lastName.length()>0)

        str+=" where ";
        str += " username like '"+username+"%' ";

        str+= " LIMIT ? OFFSET  ?";
        return findAllP(index,count,str);
    }

    public int findCount(String username) {
        String str = "select Count(*) from users ";
        str+=" where ";
        str += " username like '"+username+"%' ";
        return findCountP(str);
    }
}
