package socialnetwork.repository.database;

import socialnetwork.domain.Message;
import socialnetwork.domain.ReplyMessage;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MessageDbRepository extends RepoBaza<Long, Message> {

    private int cnt=0;
    //String select="SELECT * from mesaje";
    public MessageDbRepository(String url, String username, String password)
    {
        super("SELECT * from mesaj",
                "INSERT INTO mesaj" +
                        "  (id, expeditor,data,mesaj,reply) VALUES " +
                        " (?, ?, ? ,?,?);",
                "DELETE FROM mesaj WHERE ID = ? ",
                "UPDATE mesaj " +
                        "SET  destinatari= ?"+
                        "WHERE id=?",url, username, password,
                "select * from mesaj "+"where id=?"
                );
    }



    @Override
    protected void patern(PreparedStatement statement, Long id) {
        try {

            statement.setInt(1, id.intValue());
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    @Override
    public Message parsez(ResultSet resultSet,Connection connection,PreparedStatement statement) {
        Message m=null;
        try {
            Long id = resultSet.getLong("id");
            Long From = resultSet.getLong("expeditor");
            //String To = resultSet.getString("destinatari");

            Utilizator f=new Utilizator("Aa","Bb");
            f.setId(From);

            String s="";
            List<Utilizator> lst=new ArrayList<Utilizator>();

            String cauta="select * from destinatari "+"where id_mesaj=?";
            /*try
                  {
                      //statement = null;
                      statement = connection.prepareStatement(cauta);
                    statement.setInt(1,id.intValue());
                      ResultSet rst = statement.executeQuery();

                      //int cnt=0;
                while (rst.next()) {
                    cnt++;
                    System.out.println(cnt);
                   Long d=rst.getLong("id_utiliz");
                   Utilizator ut=new Utilizator("Aa","Bb");
                   ut.setId(d);
                   lst.add(ut);

                }
                      System.out.println("urmator");
            } catch (Exception e) {
                e.printStackTrace();
            }*/


            s=resultSet.getString("data");
            LocalDateTime data = LocalDateTime.parse(s);
            s=resultSet.getString("mesaj");
            m=new Message(f,lst,s,data);
            m.setId(id);
            String repl=resultSet.getString("reply");
            if(!repl.equals("0")) {
                ReplyMessage m2=new ReplyMessage(f,lst,s,data);
                m2.setReply(findOne(Long.parseLong(repl)));
                m2.setId(id);
                m=m2;
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }


        return m;
    }

    @Override
    protected void inserare(PreparedStatement preparedStatement, Message entity) {
        try
        {
            preparedStatement.setInt(1,entity.getId().intValue());
            preparedStatement.setInt(2,entity.getFrom().getId().intValue());

            preparedStatement.setString(3,entity.getData().toString());
            preparedStatement.setString(4,entity.getMessage());

            add_destinatari(entity);
            if(entity.getReply()==null)
                preparedStatement.setInt(5,0);
            else
                preparedStatement.setInt(5,entity.getReply().getId().intValue());
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    @Override
    public Message delete(Long aLong) {
        return null;
    }

    private void add_destinatari(Message entity) {
        String ins="INSERT INTO destinatari" +
                "  (id_mesaj,id_utiliz) VALUES " +
                " (?, ?);";
        try (Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword()))
             {


                 List<Utilizator> lst=entity.getTo();
                 for(Utilizator ut:lst)
                 {
                     Long f=entity.getId();
                     Long g=ut.getId();
                     PreparedStatement statement = connection.prepareStatement(ins);
                     statement.setInt(1,f.intValue());
                     statement.setInt(2,g.intValue());
                     statement.executeUpdate();
                 }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String lista(List<Utilizator> to) {
        List<Long>lst=new ArrayList<>();
        for(Utilizator ut:to)
        {
            lst.add(ut.getId());
        }
        return ""+lst;
    }


    public void get_destinatari(List<Message> mesaje) {
        String cauta="select * from destinatari ";
        Map<Long,Message> mp = new HashMap<>();
        for(Message m:mesaje)
            mp.put(m.getId(),m);
        List<Utilizator> lst = new ArrayList<>();
            try (
                    Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword());
                 PreparedStatement statement = connection.prepareStatement(cauta))
                  {
                      //statement.setInt(1,entity.getId().intValue());
                      ResultSet rst = statement.executeQuery();

                      int cnt=0;
                while (rst.next()) {
                    cnt++;
                    System.out.println(cnt);
                    Long id =rst.getLong("id_mesaj");
                    if(mp.get(id)==null)
                        continue;
                   Long d=rst.getLong("id_utiliz");
                   Utilizator ut=new Utilizator("Aa","Bb");
                   ut.setId(d);
                   //lst.add(ut);
                    mp.get(id).addTo(ut);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            //entity.setTo(lst);
    }

    public void getReceptori(List<Message> mesaje) {

        String cauta = "select * from destinatari" ;
        Map<Long,Message> mp = new HashMap<>();
        for(Message m:mesaje)
            mp.put(m.getId(),m);
        try (
                Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword());
                PreparedStatement statement = connection.prepareStatement(cauta))
        {
            //statement.setInt(1,entity.getId().intValue());
            ResultSet rst = statement.executeQuery();

            int cnt=0;
            while (rst.next()) {
                cnt++;
                System.out.println(cnt);
                Long id =rst.getLong("id_mesaj");
                if(mp.get(id)==null)
                    continue;
                Long d=rst.getLong("id_utiliz");
                Utilizator ut=new Utilizator("Aa","Bb");
                ut.setId(d);
                //lst.add(ut);
                mp.get(id).addTo(ut);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
