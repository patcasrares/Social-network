package socialnetwork.repository.database;

import socialnetwork.domain.Cerere;
import socialnetwork.domain.Eveniment;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EvenimentDbRepository extends RepoBaza<Long, Eveniment> {

    //String select="SELECT * from mesaje";
    public EvenimentDbRepository(String url, String username, String password)
    {
        super("SELECT * from evenimente",
                "INSERT INTO evenimente" +
                        "  (id, descriere, data) VALUES " +
                        " (?, ?, ?);",
                "DELETE FROM emitator WHERE id = ?  ",
                "UPDATE cereri " +
                        "SET  status= ?"+
                        "WHERE emitator=? AND receptor=?",url, username, password,
                "select * from evenimente "+"where id=? " //or (receptor=? and emitator=?))"
        );
    }

    @Override
    protected void patern(PreparedStatement statement, Long id) {
        try {

            statement.setInt(1, id.intValue());
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    @Override
    public Eveniment parsez(ResultSet resultSet, Connection connection, PreparedStatement statement) {
        Eveniment ev=null;
        try {
            Long id = resultSet.getLong("id");
            String descriere = resultSet.getString("descriere");
            String data = resultSet.getString("data");
            ev=new Eveniment(descriere,LocalDateTime.parse(data));
            ev.setId(id);

        }
        catch(Exception e)
        {
            System.out.println(e);
        }


        return ev;
    }

    @Override
    protected void inserare(PreparedStatement preparedStatement, Eveniment entity) {
        try
        {
            preparedStatement.setInt(1,entity.getId().intValue());
            preparedStatement.setString(2,entity.getDescriere());
            preparedStatement.setString(3,entity.getDate().toString());
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public void abonare(Long idEveniment,Long idUser)
    {
        String ins = "INSERT INTO abonati" +
                "  (id_eveniment, id_user) VALUES " +
                " (?, ?);";
        try (Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword());

             PreparedStatement preparedStatement = connection.prepareStatement(ins)) {
            preparedStatement.setInt(1, idEveniment.intValue());
            preparedStatement.setInt(2, idUser.intValue());

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }

    }

    public Set<Long> abonari(Long id)
    {
        Set<Long> set = new HashSet<>();
        String cauta="select id_eveniment from abonati "+"where id_user=?";
        try (Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword());

             PreparedStatement preparedStatement = connection.prepareStatement(cauta)) {
            preparedStatement.setLong(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Long idEv = resultSet.getLong("id_eveniment");
                set.add(idEv);
            }

        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }
        return set;
    }

    public void dezabonare(Long idEveniment,Long idUser)
    {
        String ins = "delete from abonati where" +
                "  id_eveniment=? and id_user =?";
        try (Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword());

             PreparedStatement preparedStatement = connection.prepareStatement(ins)) {
            preparedStatement.setInt(1, idEveniment.intValue());
            preparedStatement.setInt(2, idUser.intValue());

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }

    }



    @Override
    public Eveniment delete(Long aLong) {
        throw new UnsupportedOperationException();
    }

    public List<Eveniment> findAll(int pag, int count) {
        String str = "select * from evenimente ";
        str += " where data > '" + LocalDateTime.now() + "' ";
        str += " limit ? offset ?";
        pag++;
        System.out.println("pagina este DB  "+pag);
        int st=(pag-1)*count+1;
        int dr=st+count-1;

        // String str = "select * from users  LIMIT ? OFFSET  ?";
        List<Eveniment> lst = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword());
             PreparedStatement statement = connection.prepareStatement(str))
        {
            statement.setInt(1,count);
            statement.setInt(2,st-1);
            ResultSet resultSet = statement.executeQuery();
            while(resultSet.next()) {
                Eveniment ev = parsez(resultSet, connection, statement);
                parsez(resultSet, connection, statement);
                lst.add(ev);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lst;
    }

    public int countEvActive()
    {
        String str = "select Count(*) from evenimente";
        str += " where data > '" + LocalDateTime.now() + "' ";
        return count(str);
    }

    public int count()
    {
        String str = "select max(id) from evenimente";
        //str += " where data > '" + LocalDateTime.now() + "' ";
        return count(str);
    }

    public int count(String str) {
       // String str = "select Count(*) from evenimente";
        //str += " where data > '" + LocalDateTime.now() + "' ";
        int ret = 0;
        try (Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword());

             PreparedStatement preparedStatement = connection.prepareStatement(str)) {
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next())
            {
                ret= resultSet.getInt(1);
            }

        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }
        return ret;
    }

    public void notificare(Long idE, Long idU) {
        String ins = "INSERT INTO notificari" +
                "  (id_ev, id_user) VALUES " +
                " (?, ?);";
        System.out.println(ins);
        try (Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword());

             PreparedStatement preparedStatement = connection.prepareStatement(ins)) {
            preparedStatement.setInt(1, idE.intValue());
            preparedStatement.setInt(2, idU.intValue());

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }

    }

    public void notNotificare(Long idE, Long idU) {
        String ins = "delete from notificari where" +
                "  id_ev=? and id_user =?";
        System.out.println(ins);
        try (Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword());

             PreparedStatement preparedStatement = connection.prepareStatement(ins)) {
            preparedStatement.setInt(1, idE.intValue());
            preparedStatement.setInt(2, idU.intValue());

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }
    }

    public List<Eveniment> notificari(Long id) {
        String cauta="select * from notificari "+"where id_user=?";
        System.out.println("Dumnezeu "+cauta);
        List<Eveniment> lst = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(getUrl(), getUsername(), getPassword());

             PreparedStatement preparedStatement = connection.prepareStatement(cauta)) {
            preparedStatement.setLong(1, id);

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Long idEv = resultSet.getLong("id_ev");
                lst.add(findOne(idEv));
            }

        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }
        return lst;
    }
}
