package socialnetwork.repository.database;

import socialnetwork.domain.Cerere;
import socialnetwork.domain.Entity;
import socialnetwork.domain.Utilizator;
import socialnetwork.domain.validators.Validator;
import socialnetwork.repository.Repository;

import java.sql.*;

import java.util.*;




public abstract class RepoBaza<ID, E extends Entity<ID>>  implements Repository<ID,E> {


    //Map<ID, E> entities=null;
    private String url;
    private String username;
    private String password;
    private Validator<E> validator;

    private String tabel="";

    private String SELECT_SQL="SELECT * from users";

    private String INSERT_SQL = "INSERT INTO users" +
            "  (id, nume, prenume) VALUES " +
            " (?, ?, ?);";

    private String DELETE_SQL = "DELETE FROM users WHERE ID = ? ";

    private String UPDATE_SQL = "UPDATE user " +
            "SET  id= ?,nume=?,prenume=? "+
            "WHERE id=?";
    private String cauta="select * from users "+"where id=?";





    public RepoBaza(String SELECT_SQL,String INSERT_SQL,String DELETE_SQL,String UPDATE_SQL,String url, String username, String password,String cauta)
    {
         this.SELECT_SQL=SELECT_SQL;
         this.INSERT_SQL=INSERT_SQL;
         this.DELETE_SQL=DELETE_SQL;
         this.UPDATE_SQL=UPDATE_SQL;

        this.url = url;
        this.username = username;
        this.password = password;
        this.cauta = cauta;
        findAll();
    }

    public String getUrl()
    {
        return url;
    }

    public String getUsername()
    {
        return username;
    }

    public String getPassword()
    {
        return password;
    }


    @Override
    public  E findOne(ID id)
    {
        E element=null;
        try (Connection connection = DriverManager.getConnection(url, username, password);
        )
        {
            PreparedStatement statement = connection.prepareStatement(cauta);
            patern(statement,id);
            //statement.setInt(1, aLong.intValue());
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                element=parsez(resultSet,connection,statement);

            }
            //return users;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return element;
    }

    protected abstract void patern(PreparedStatement statement, ID id);

    @Override
    public Iterable<E> findAll() {

        Map<ID,E> entities=new HashMap<ID,E>();
        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement statement = connection.prepareStatement(SELECT_SQL);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                /*Long id = resultSet.getLong("id");
                String firstName = resultSet.getString("nume");
                String lastName = resultSet.getString("prenume");*/


                E aux=parsez(resultSet,connection,statement);

                entities.put(aux.getId(),aux);

            }
            return entities.values();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return entities.values();
    }

    public abstract E parsez(ResultSet resultSet,Connection connection,PreparedStatement statement);

    @Override
    public E save(E entity) {
        if(findOne(entity.getId())!=null)
        {
            throw new DatabaseException("este deja acest id");
        }
        //int A=entity.getId().intValue();
        //String B=entity.getFirstName();
        //String C=entity.getLastName();

        try (Connection connection = DriverManager.getConnection(url, username, password);
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_SQL)) {
            //preparedStatement.setInt(1, A);
            //preparedStatement.setString(2, B);
            //preparedStatement.setString(3, C);
            
            inserare(preparedStatement,entity);

            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }
        return null;
    }

    protected abstract void inserare(PreparedStatement preparedStatement, E entity);

    @Override
    abstract public E delete(ID id);


    @Override
    public E update(E entity) {
        try (Connection connection = DriverManager.getConnection(url, username, password);

             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_SQL)) {
            //preparedStatement.setInt(1, A);

            modificare(preparedStatement,entity);
            System.out.println(preparedStatement);
            // Step 3: Execute the query or update query
            preparedStatement.executeUpdate();
        } catch (Exception e) {

            // print SQL exception information
            System.out.println(e);
        }
        return entity;
    }

    public void modificare(PreparedStatement preparedStatement, E entity)
    {
        throw new UnsupportedOperationException();
    }

    @Override
    public ID findByEmail(String str)
    {
        throw new UnsupportedOperationException();
    }


    @Override
    public ID findByUsername(String str)
    {
        throw new UnsupportedOperationException();
    }



}
