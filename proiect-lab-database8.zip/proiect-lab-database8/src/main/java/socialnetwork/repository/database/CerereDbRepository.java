package socialnetwork.repository.database;

import socialnetwork.domain.Cerere;
import socialnetwork.domain.Message;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class CerereDbRepository extends RepoBaza<Tuple<Long,Long>, Cerere> {

    //String select="SELECT * from mesaje";
    public CerereDbRepository(String url, String username, String password)
    {
        super("SELECT * from cereri",
                "INSERT INTO cereri" +
                        "  (Emitator, receptor, status, data) VALUES " +
                        " (?, ?, ?, ?);",
                "DELETE FROM cereri WHERE emitator = ? AND receptor=? ",
                "UPDATE cereri " +
                        "SET  status= ?"+
                        "WHERE emitator=? AND receptor=?",url, username, password,
                "select * from cereri "+"where emitator=? and receptor=?" //or (receptor=? and emitator=?))"
        );
    }




    @Override
    protected void patern(PreparedStatement statement, Tuple<Long, Long> id) {
        try {
            Long f = id.getLeft();
            Long g = id.getRight();
            statement.setInt(1, f.intValue());
            statement.setInt(2, g.intValue());

        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    @Override
    public Cerere parsez(ResultSet resultSet,Connection connection,PreparedStatement statement) {
        Cerere m=null;
        try {
            Long id1 = resultSet.getLong("Emitator");
            Long id2 = resultSet.getLong("receptor");
            String status = resultSet.getString("status");
            String data = resultSet.getString("data");
            m=new Cerere(id1,id2);
            m.setDate(LocalDateTime.parse(data));
            m.setStatus(status);

        }
        catch(Exception e)
        {
            System.out.println(e);
        }


        return m;
    }

    @Override
    protected void inserare(PreparedStatement preparedStatement, Cerere entity) {
        try
        {
            preparedStatement.setInt(1,entity.getSender().intValue());
            preparedStatement.setInt(2,entity.getRecv().intValue());
            preparedStatement.setString(3,entity.getStatus());
            preparedStatement.setString(4,entity.getDate().toString());

        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    @Override
    public Cerere delete(Tuple<Long, Long> longLongTuple) {
        try(Connection connection = DriverManager.getConnection(super.getUrl(), super.getUsername(), super.getPassword());
        ){
            String s = "DELETE FROM cereri WHERE emitator =? AND receptor=? ";
            PreparedStatement preparedStatement = connection.prepareStatement(s);
            preparedStatement.setInt(1, longLongTuple.getLeft().intValue());
            preparedStatement.setInt(2, longLongTuple.getRight().intValue());

            System.out.println(preparedStatement);
            preparedStatement.executeUpdate();

        }
        catch(Exception e){
            System.out.println(e);

        }
        return null;
    }

    private String lista(List<Utilizator> to) {
        List<Long>lst=new ArrayList<>();
        for(Utilizator ut:to)
        {
            lst.add(ut.getId());
        }
        return ""+lst;
    }

    @Override
    public void modificare(PreparedStatement preparedStatement, Cerere entity) {
        try
        {
            preparedStatement.setString(1,entity.getStatus());
            preparedStatement.setInt(2,entity.getSender().intValue());
            preparedStatement.setInt(3,entity.getRecv().intValue());
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    public int nrCereri(Long id, int type) {
        int ret = 0;
        String str = "select count(*) from cereri ";
        if(type == 0)
            str += "where emitator = " + id.intValue();
        else
            str += "where receptor = " + id.intValue();
        str +=" and status = 'pending'";
        System.out.println(str);
        try(Connection connection = DriverManager.getConnection(super.getUrl(), super.getUsername(), super.getPassword());
        ) {
            PreparedStatement preparedStatement = connection.prepareStatement(str);
            ResultSet z = preparedStatement.executeQuery();
            if(z.next())
                ret = z.getInt(1);
        }
        catch(Exception e)
        {

        }
        System.out.println(ret);
        return ret;
    }

    public List<Cerere> cereri(Long id, int index, int count, int type) {

        List<Cerere > lst = new ArrayList<>();
        String str = "select * from cereri ";
        if(type == 0)
            str += "where emitator = " + id.intValue();
        else
            str += "where receptor = " + id.intValue();
        str += " and status = 'pending' ";

        int st=index*count;
        str += " LIMIT "+ count+" OFFSET "+ st;

        System.out.println(str);

        try(Connection connection = DriverManager.getConnection(super.getUrl(), super.getUsername(), super.getPassword());
        ) {
            PreparedStatement preparedStatement = connection.prepareStatement(str);
            ResultSet z = preparedStatement.executeQuery();
            while(z.next()) {
                Cerere c = parsez(z, connection, preparedStatement);
                parsez(z, connection, preparedStatement);
                lst.add(c);
            }

        }
        catch(Exception e)
        {

        }
        return lst;
    }
}
