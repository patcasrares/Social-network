package socialnetwork.repository.file;

import socialnetwork.domain.Message;
import socialnetwork.domain.Prietenie;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;
import socialnetwork.domain.validators.UtilizatorValidator;
import socialnetwork.domain.validators.Validator;
import socialnetwork.repository.RepoException;
import socialnetwork.repository.Repository;

import java.io.*;
import java.time.LocalDateTime;
import java.util.*;

public class MessageFile extends AbstractFileRepository<Long, Message> {

    public MessageFile(String fileName, Validator<Message> validator) {
        super(fileName, validator);
    }

    public Message extractEntity(List<String> attributes) {
        Message m=null;
        System.out.println(attributes);
        Long id=Long.parseLong(attributes.get(0));
        Long id_from=Long.parseLong(attributes.get(1));
        System.out.println(id_from);

        Utilizator from=new Utilizator("Aa","Bb");
        from.setId(id_from);
        //Utilizator from=repo.findOne(id_from);
        String s="";
        List<Utilizator> lst=new ArrayList<Utilizator>();
        for(int i=0;i<attributes.get(2).length();i++)
        {
            char ch=attributes.get(2).charAt(i);
            if(!Character.isDigit(ch))
            {
                if(!s.equals("")) {
                    Utilizator ut=new Utilizator("Aa","Bb");
                    ut.setId(Long.parseLong(s));
                    lst.add(ut);
                }
                s="";
                continue;
            }
            s=s+ch;

        }
        LocalDateTime data = LocalDateTime.parse(attributes.get(3));
        s="";
        for(int i=4;i<attributes.size()-1;i++)
        {
            s=s+attributes.get(i);
        }
        m=new Message(from,lst,s,data);
        m.setId(id);
        String repl=attributes.get(attributes.size()-1);
        if(!repl.equals("0")) {
            //m.setReply(findOne(Long.parseLong(repl)));
        }
        System.out.println(m);
        return m;

        /*List<Utilizator>lst=new ArrayList<Utilizator>();
        lst.add(null);
        return new Message(null,lst,"a");*/
    }




    protected String createEntityAsString(Message entity) {
        return entity.toString();

    }

}