package socialnetwork.service;

import controller.PageDTO;
import socialnetwork.domain.Cerere;
import socialnetwork.domain.UserDTO;
import socialnetwork.domain.Utilizator;

import java.util.ArrayList;
import java.util.List;

public class PageService {

    private  EvenimenteService srvE;
    private Utilizator U;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;


    public PageService(Long id, UtilizatorService srvU,
            PrietenieService srvP,
            MessageService srvM,
            CerereService srvC,EvenimenteService srvE)
    {
        this.U = srvU.findOne(id);
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
        this.srvE = srvE;
    }

    public PageDTO getDTO()
    {
        PageDTO page = new PageDTO();
        page.setNrUser(srvU.nrUtilizatori());
        //List<Utilizator> lst = srvU.getAll(1,5);
        page.setLstU(srvU.getAll(0,4));

        System.out.println("heooo");

        page.setNrCereriPrimite(srvC.nrCereri(U.getId(),1));
        System.out.println("xjzk");
        page.setCereriPrimite(srvC.cereri(U.getId(),0,5,1));
        System.out.println(srvC.cereri(U.getId(),0,5,1));

        System.out.println("heooo");

        page.setNrCereriTrimise(srvC.nrCereri(U.getId(),0));
        page.setCereriTrimise(srvC.cereri(U.getId(),0,5,0));

        page.setAbonari(srvE.getAbonari(U.getId()));

        page.setU(U);

        page.setNrEvActive(srvE.nrEvenimenteActive());
        page.setNrEv(srvE.nrEvenimente());

        page.setEvenimente(srvE.getAll(0,3));

            page.setConversatii(srvM.getConversatii(U.getId()));

            page.setNotificari(srvE.getNotificari(U.getId()));



        List<UserDTO> lst = new ArrayList<>();
        for(Utilizator ut2:page.getLstU()) {
            Utilizator ut = srvU.findOne(ut2.getId());
            UserDTO udt = new UserDTO(ut);
            if(U.getFriends().contains(ut))
                udt.setStatus("Prieteni");
            else {
                if (srvC.exista(U.getId(), ut.getId())) {
                    udt.setStatus("Cerere trimisa");
                }
                if(U.getId().equals(ut.getId()))
                    udt.setStatus("Your username");
            }
            lst.add(udt);

        }
        page.setLstDTO(lst);
        return page;

    }


}
