package socialnetwork.service;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import socialnetwork.domain.Eveniment;
import socialnetwork.domain.Utilizator;
import socialnetwork.domain.validators.EvenimentValidator;
import socialnetwork.domain.validators.Validator;
import socialnetwork.repository.database.EvenimentDbRepository;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class EvenimenteService {





    private EvenimentDbRepository repo;
    private Validator<Eveniment> valid;
    private List<Eveniment> lstNotif;

    public EvenimenteService(EvenimentDbRepository repo)
    {
        this.repo = repo;
        this.valid = new EvenimentValidator();
    }

    public void addEvent(Eveniment ev)
    {
        valid.validate(ev);
        repo.save(ev);
    }

    public List<Eveniment> getAll() {
        List<Eveniment>lst = new ArrayList<>();
        for(Eveniment ev:repo.findAll()) {
            System.out.println(ev.getId());
            lst.add(ev);
        }
        //System.out.println(lst);
        return lst;
    }

    public void dezabonare(Long idEv, Long idUser) {
        repo.dezabonare(idEv,idUser);
    }

    public Set<Long> getAbonari(Long id)
    {
        return repo.abonari(id);
    }

    public void abonare(Long idEv, Long idUser) {
        repo.abonare(idEv,idUser);
    }

    public int nrEvenimente() {
        return repo.count();
    }

    public List<Eveniment> getAll(int index, int count) {
        return repo.findAll(index,count);
    }

    public int nrEvenimenteActive() {
        return repo.countEvActive();
    }

    public void notificare(Long idE, Long idU) {
        repo.notificare(idE,idU);
    }

    public void notNotificare(Long idE, Long idU) {
        repo.notNotificare(idE,idU);
    }

    public List<Eveniment> getNotificari(Long id) {
        
        return repo.notificari(id);
    }
}
