package socialnetwork.ui;

import socialnetwork.domain.*;
import socialnetwork.domain.validators.ValidationException;
import socialnetwork.repository.RepoException;
import socialnetwork.repository.database.DatabaseException;
import socialnetwork.service.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Consola {
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;


    public Consola(UtilizatorService srvU,PrietenieService srvP,MessageService srvM,CerereService srvC)
    {
        this.srvU=srvU;
        this.srvP=srvP;
        this.srvM=srvM;
        this.srvC=srvC;
    }

    //verifica daca s-a introdus un int ce poate fi Id
    //s-String
    //arunca UI exception daca nu e ok
    public void verific_id(String s) throws UiException
    {
        if(s.length()==0)
            throw new UiException("numarul nu este un sir vid");

        for(int i=0;i<s.length();i++)
            if(!Character.isDigit(s.charAt(i)))
                throw new UiException("numarul contine doar cifre");
    }

    public boolean verific_numar(String s)
    {
        boolean vf=true;
        try
        {
            verific_id(s);
        }
        catch(Exception e)
        {
            System.out.println(e);
            vf=false;
        }
        return vf;
    }

    public boolean vf_luna(String s,int luna)
    {
        for(int i=0;i<s.length();i++)
        {
            if(s.charAt(i)=='-')
            {
                int f=s.charAt(i+1);
                f-='0';
                int g=s.charAt(i+2);
                g-='0';
                f=f*10+g;
                System.out.println(f+" "+luna);
                return (f==luna);
            }
        }
        return false;
    }

    /*
    * afiseaza meniul si ghideaza utilizatorul sa foloseasca aplicatia
    * */
    public void run()
    {
        String cmd;
        Scanner rd=new Scanner(System.in);
        while(true) {
            System.out.println("introduceti 0 pt oprire");
            System.out.println("introduceti 1 pt add utilizator");
            System.out.println("introduceti 2 pt remove utilizator");
            System.out.println("introduceti 3 pt add prietenie");
            System.out.println("introduceti 4 pt remove prietenie");
            System.out.println("introduceti 5 pt nr de componente");
            System.out.println("introduceti 6 pt componenta maximala");
            System.out.println("introduceti 7 pt lista de prieteni a unui utilizator");
            System.out.println("introduceti 8 pt lista prietenilor a unui utilizator facuti int-o anumita luna");
            System.out.println("introduceti 9 pt a trimite un mesaj");
            System.out.println("introduceti 10 pt a trimite un reply");
            System.out.println("introduceti 11 pt a vedea o conversatie");
            System.out.println("introduceti 12 pt a trimite o cerere de prietenie");
            System.out.println("introduceti 13 pt a accepta o cerere de prietenie");
            System.out.println("introduceti 14 pt a refuza o cerere de prietenie");
            System.out.print("introduceti o comanda ");
            cmd = rd.nextLine();
            if (cmd.equals("0"))
                break;

            if (cmd.equals("-1"))
            {

                Utilizator ut=srvU.findOne(2L);
                System.out.println(ut);
                continue;
            }

            if (cmd.equals("1")) {
                int vf = 1;
               /* System.out.print("introduceti id-ul ");
                String id = rd.nextLine();

                try {
                    verific_id(id);
                } catch (UiException e) {
                    vf = 0;
                    System.out.println(e);
                }
                if (vf == 0)
                    continue;*/
                int id=srvU.maxId();
                System.out.print("introduceti firstName ");
                String firstName = rd.nextLine();
                System.out.print("introduceti lastName ");
                String lastName = rd.nextLine();
                Utilizator ut = new Utilizator(firstName, lastName);
                ut.setId(new Long(id));

                try {
                    srvU.addUtilizator(ut);
                    System.out.println("id ul este "+id);
                } catch (ValidationException e) {
                    System.out.println(e);
                }
                catch (DatabaseException e) {
                    System.out.println(e);
                }

                continue;
            }

            if (cmd.equals("2")) {
                System.out.print("introduceti id-ul ");
                String id = rd.nextLine();

                int vf = 1;
                try {
                    verific_id(id);
                } catch (UiException e) {
                    vf = 0;
                    System.out.println(e);
                }
                if (vf == 0)
                    continue;
                try {
                    srvU.delete(Long.parseLong(id));
                } catch (Exception e) {
                    System.out.println(e);
                }

                continue;
            }

            if (cmd.equals("3")) {
                System.out.print("introduceti primul id din prietenie ");
                String id1 = rd.nextLine();
                System.out.print("introduceti al doilea id din prietenie ");
                String id2 = rd.nextLine();
                int vf = 1;
                try {
                    verific_id(id1);
                    verific_id(id2);
                } catch (UiException e) {
                    vf = 0;
                    System.out.println(e);
                }
                if (vf == 0)
                    continue;
                Tuple t = new Tuple(Long.parseLong(id1), Long.parseLong(id2));
                Prietenie p = new Prietenie();
                p.setId(t);
                try {
                    srvP.addPrietenie(p);
                } catch (ValidationException e) {
                    System.out.println(e);
                }
                catch (ServiceException e) {
                    System.out.println(e);
                }
                catch (DatabaseException e) {
                    System.out.println(e);
                }
                continue;
            }

            if (cmd.equals("4")) {
                System.out.print("introduceti primul id din prietenie ");
                String id1 = rd.nextLine();
                System.out.print("introduceti al doilea id din prietenie ");
                String id2 = rd.nextLine();
                int vf = 1;
                try {
                    verific_id(id1);
                    verific_id(id2);
                } catch (UiException e) {
                    vf = 0;
                    System.out.println(e);
                }
                if (vf == 0)
                    continue;
                Tuple t = new Tuple(Long.parseLong(id1), Long.parseLong(id2));
                Prietenie p = new Prietenie();
                p.setId(t);
                try {
                    srvP.removePrietenie(p);
                } catch (ValidationException e) {
                    System.out.println(e);
                }
                catch (ServiceException e) {
                    System.out.println(e);
                }
                catch (DatabaseException e) {
                    System.out.println(e);
                }
                continue;
            }

            if(cmd.equals("5"))
            {
                System.out.println(srvU.componente());
                continue;
            }

            if(cmd.equals("6"))
            {
                ArrayList<Utilizator> ret=srvU.maximala();
                for(Utilizator i:ret)
                    System.out.println(i);
                continue;
            }

            if(cmd.equals("7"))
            {
                System.out.print("introduceti id-ul ");
                String id = rd.nextLine();

                int vf = 1;
                try {
                    verific_id(id);
                } catch (UiException e) {
                    vf = 0;
                    System.out.println(e);
                }
                if(vf==0)
                    continue;
                try {
                    List<PrietenDTO> lst = srvP.prieteni(id);
                    lst.forEach(System.out::println);
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }

                continue;
            }

            if(cmd.equals("8"))
            {
                System.out.print("introduceti id-ul ");
                String id = rd.nextLine();
                System.out.print("introduceti luna ");
                String lun= rd.nextLine();

                int vf = 1;
                try {
                    verific_id(id);
                    verific_id(lun);
                } catch (UiException e) {
                    vf = 0;
                    System.out.println(e);
                }
                Integer luna2=Integer.parseInt(lun);
                int luna=luna2.intValue();
                if(vf==0)
                    continue;

                try {
                    List<PrietenDTO> lst = srvP.prieteni_luna(id,luna);
                    lst.forEach(System.out::println);
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }

                continue;
            }

            if(cmd.equals("9"))
            {
                int vf=0;
                System.out.print("introduceti id-ul expeditorului ");
                String id = rd.nextLine();
                Utilizator from = null;
                try {
                    verific_id(id);
                    from = srvU.findOne(Long.parseLong(id));
                    vf=1;
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
                if(vf==0)
                    continue;
                List<Utilizator> lst=new ArrayList<Utilizator>();
                System.out.println("introduceti lista de destinatari");
                while(true)
                {
                    System.out.print("introduceti id-ul urmatorului destinator sau enter daca nu mai adaugati ");
                    id = rd.nextLine();
                    if(id.equals(""))
                        break;
                    Utilizator ut=null;
                    vf=1;
                    try {
                        verific_id(id);
                        ut = srvU.findOne(Long.parseLong(id));
                    }
                    catch(Exception e)
                    {
                        System.out.println(e);
                        vf=0;
                    }
                    if(vf==1)
                        lst.add(ut);
                }


                System.out.print("introduceti mesajul: ");
                String msg = rd.nextLine();
                Message message = new Message(from,lst,msg);

                try {
                    srvM.addMessage(message);
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
                System.out.println(message.getId());
                continue;
            }

            if(cmd.equals("10"))
            {
                int vf=0;
                String id1="",id2="";
                System.out.println("introduceti id-ul expeditorului ");
                id1=rd.nextLine();
                try {
                    verific_id(id1);
                    vf=1;
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
                if(vf==0)
                    continue;
                vf=0;
                System.out.println("introduceti id-ul mesajului la acare da reply ");
                id2=rd.nextLine();
                try {
                    verific_id(id2);
                    vf=1;
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
                if(vf==0)
                    continue;
                vf=0;
                System.out.println("introduceti mesajul ");
                String msg=rd.nextLine();
                int type=0;
                System.out.print("daca vreti sa fie reply all apasati 1 ");
                String rsp=rd.nextLine();
                if(rsp.equals("1"))
                    type=1;
                try {
                    srvM.addReply(Long.parseLong(id1), Long.parseLong(id2), msg,type);
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
            }

            if(cmd.equals("11"))
            {
                System.out.print("introduceti primul id ");
                String id1=rd.nextLine();
                if(!verific_numar(id1))
                    continue;
                System.out.print("introduceti al doilea id ");
                String id2=rd.nextLine();
                if(!verific_numar(id2))
                    continue;
                List<Message> lst=null;
                try
                {
                    lst=srvM.afisare(Long.parseLong(id1),Long.parseLong(id2));
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
                System.out.println(lst);
                continue;
            }

            if(cmd.equals("12"))
            {
                System.out.print("introduceti primul id ");
                String id1=rd.nextLine();
                if(!verific_numar(id1))
                    continue;
                System.out.print("introduceti al doilea id ");
                String id2=rd.nextLine();
                if(!verific_numar(id2))
                    continue;

                try
                {
                    srvC.request(Long.parseLong(id1),Long.parseLong(id2));
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
                continue;
            }

            if(cmd.equals("13"))
            {
                System.out.print("introduceti primul id ");
                String id1=rd.nextLine();
                if(!verific_numar(id1))
                    continue;
                System.out.print("introduceti al doilea id ");
                String id2=rd.nextLine();
                if(!verific_numar(id2))
                    continue;

                try
                {
                    srvC.accepta(Long.parseLong(id1),new Tuple(Long.parseLong(id1),Long.parseLong(id2)));
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
                continue;
            }

            if(cmd.equals("14"))
            {
                System.out.print("introduceti primul id ");
                String id1=rd.nextLine();
                if(!verific_numar(id1))
                    continue;
                System.out.print("introduceti al doilea id ");
                String id2=rd.nextLine();
                if(!verific_numar(id2))
                    continue;

                try
                {
                    srvC.refuza(Long.parseLong(id1),new Tuple(Long.parseLong(id1),Long.parseLong(id2)));
                }
                catch(Exception e)
                {
                    System.out.println(e);
                }
                continue;
            }
            System.out.println("comanda invalida");
        }

    }
}
