package controller;

public class Spatiu {
}
