package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

public class NotificareController extends Control {
    @FXML
    private Label label;

    public void setText(String s)
    {
        label.setText(s);
    }

    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {

    }
}
