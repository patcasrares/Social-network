package controller;

import javafx.collections.ObservableList;
import javafx.scene.Parent;
import javafx.scene.control.Pagination;
import javafx.scene.layout.AnchorPane;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class Control {

    List<Control> ferestre= new ArrayList<>();
    private PageDTO pageDTO;
    private boolean start = true;

    public boolean getStart()
    {
        return start;
    }

    public void setStart(boolean start)
    {
        this.start = start;
    }

    public PageDTO getPageDTO()
    {
        return pageDTO;
    }

    public void addFereastra(Control fereastra)
    {
        ferestre.add(fereastra);
    }

    public void updateFerestre()
    {
        for(Control c:ferestre)
            c.restart();
    }

    public void restart() {
    }

    public abstract void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP,
                              MessageService srvM, CerereService srvC);

    public void setSrvEvent(EvenimenteService srv)
    {}

    public void parinte(SideBarController sbc)
    {}


    public <T> void  creezTabel(Pagination pagination, List<T> lst, int count, ObservableList<T>model) {

        pagination.setCurrentPageIndex(0);
        int cntP=lst.size()/count;
        if(lst.size()%count>0)
            cntP++;
        pagination.setPageCount(cntP);
        pagination.setPageFactory((index)->{
            System.out.println("Size "+lst.size());
            pagina(index,lst,model,count);
            return new AnchorPane();
        });


    }

    private <T> void pagina(int pag,List<T>lst,ObservableList<T>model,int count) {

        pag++;
        System.out.println("pagina este "+pag);
        System.out.println("Size2 "+lst.size());
        int st=(pag-1)*count+1;
        int dr=st+count-1;
        System.out.println(st+" "+dr);
        dr=Math.min(dr,lst.size());
        List<T> obj = new ArrayList<>();
        for(int i=st-1;i<dr;i++)
            obj.add(lst.get(i));
        model.setAll(obj);


    }


    public void setFerestre(Map<String, Parent> mpFerestre) {

    }

    public void setDTO(PageDTO pageDTO)
    {
        this.pageDTO = pageDTO;
    }

    /*protected void creezTabel(Pagination pagination, int count, ObservableList<Utilizator> modelUser) {
        pagination.setCurrentPageIndex(0);
        int cntP=lst.size()/count;
        if(lst.size()%count>0)
            cntP++;
        pagination.setPageCount(cntP);
        pagination.setPageFactory((index)->{
            System.out.println("Size "+lst.size());
            pagina(index,lst,model,count);
            return new AnchorPane();
        });
    }*/
}
