package controller;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.ContextMenuEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import socialnetwork.domain.Cerere;
import socialnetwork.domain.Message;
import socialnetwork.domain.PrietenDTO;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class RaportController extends Control {

    @FXML
    private AnchorPane lanc;


    @FXML
    private VBox vanc;

    @FXML
    private AnchorPane anc;

    @FXML
    private Pagination pagination1;

    @FXML
    private Pagination pagination2;

    private List<Message> mesage ;
    private List<Utilizator> utilizatori;

    @FXML
    private DatePicker dateStart;

    @FXML
    private DatePicker dateEnd;

    private boolean prietenFixat =false;

    @FXML
    private VBox vb;
    private List<PrietenDTO> lstFriends;

    private List<Message> lstMessage;

    ObservableList<PrietenDTO> modelFriends = FXCollections.observableArrayList();

    ObservableList<Message> modelMessage = FXCollections.observableArrayList();

    private Utilizator U;

    private int count = 3;

    @FXML
    private TableView<Message> mesaje;

    @FXML
    TableColumn<Message, String>tableColumnFrom;

    @FXML
    TableColumn<Message, String>tableColumnMesaj;

    @FXML
    TableColumn<Message, String>tableColumnDataMesaj;



    @FXML
    TableColumn<PrietenDTO, String> tableColumnPrieten;

    @FXML
    TableColumn<PrietenDTO, String> tableColumnDataPrieten;

    @FXML
    private TableView<PrietenDTO> tableFriend;

    private UtilizatorService srvU;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;

    List<Message> lstMPdf;
    List<PrietenDTO> lstPPdf;


    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {

        System.out.println("sdajk");
        this.U = U;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;

        //dateStart.setStyle("fx-padding: 0.588883em 0.5em 0.666667em 0.5em; linear-gradient(to bottom, derive(black,-3%), derive(black,5%) 50%, derive(black,-3%)); -fx-background-insets: 0 0 0 0, 0 0 1 0;");

        dateStart.getEditor().textProperty().addListener(c->filterDate());
        dateEnd.getEditor().textProperty().addListener(c->filterDate());

        tableColumnPrieten.setCellValueFactory(new PropertyValueFactory<PrietenDTO , String>("Username"));

        tableColumnDataPrieten.setCellValueFactory(new PropertyValueFactory<PrietenDTO , String>("DataP"));

        tableColumnFrom.setCellValueFactory(new PropertyValueFactory<Message , String>("Username"));
        tableColumnMesaj.setCellValueFactory(new PropertyValueFactory<Message , String>("Message"));
        tableColumnDataMesaj.setCellValueFactory(new PropertyValueFactory<Message , String>("DataP"));

        tableFriend.setItems(modelFriends);
        mesaje.setItems(modelMessage);

        //creezTabel(pagination,lst,count,modelCereri);
        reload();
    }

    private void filterDate() {
        try {
            String start = dateStart.getEditor().getText();
            String end = dateEnd.getEditor().getText();


            //LocalDateTime z = LocalDateTime.parse(start);
            // System.out.println(z);
            System.out.println(start + " " + end);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
            System.out.println(formatter.format(LocalDateTime.now()));

            SimpleDateFormat sdformat = new SimpleDateFormat("dd.MM.yyyy");
            Date d1 = sdformat.parse(start);
            Date d2 = sdformat.parse(end);
            System.out.println(d1);
            System.out.println(d2);
            //reload();




            List<Message> lst1 = lstMessage.stream()
                    .filter(x-> {
                        String s = formatter.format(x.getData());
                        try {
                            Date d3 = sdformat.parse(s);
                            return (d3.compareTo(d1)>=0&&d3.compareTo(d2)<=0);
                        }
                        catch(Exception e)
                        {
                            return false;
                        }

                    })
                    .collect(Collectors.toList());

            List<PrietenDTO> lst2 = lstFriends.stream()
                    .filter(x-> {
                        String s = formatter.format(x.getData());
                        try {
                            Date d3 = sdformat.parse(s);
                            return (d3.compareTo(d1)>=0&&d3.compareTo(d2)<=0);
                        }
                        catch(Exception e)
                        {
                            return false;
                        }

                    })
                    .collect(Collectors.toList());

            lstMPdf = lst1;
            lstPPdf = lst2;

            creezTabel(pagination2,lst2,count,modelFriends);


            creezTabel(pagination1,lst1,count,modelMessage);
        }
        catch(Exception e)
        {

        }

    }

    private void reload() {
        System.out.println("ok");

        lstFriends = srvP.prieteni(U.getId().toString());
        lstMessage = srvM.getPrimite(U);

        lstMPdf = lstMessage;

        lstPPdf = lstFriends;

        //modelFriends.setAll(lstFriends);

        //modelMessage.setAll(lstMessage);

        creezTabel(pagination2,lstFriends,count,modelFriends);


        creezTabel(pagination1,lstMessage,count,modelMessage);
    }


    public void filter(Utilizator ut) {
        creezTabel(pagination1,lstMessage.stream()
                .filter(x->x.getFrom().getId().equals(ut.getId()))
                .collect(Collectors.toList()),count,modelMessage);
        /*modelMessage.setAll(
                lstMessage.stream()
                .filter(x->x.getFrom().getId().equals(ut.getId()))
                .collect(Collectors.toList())
        );*/

        vanc.getChildren().remove(anc);
        vanc.getChildren().remove(lanc);
        vanc.getChildren().remove(pagination2);
        prietenFixat = true;
    }


    private void addPdf()
    {
        try {
            com.itextpdf.text.Document document = new Document();

            PdfWriter.getInstance(document, new FileOutputStream("Raport.pdf"));

            document.open();
            Paragraph paragraph = new Paragraph("NEW FRIENDS FOR USER "+U.getUsername());
            document.add(paragraph);

            paragraph = new Paragraph("Mesaje");
            document.add(paragraph);

            PdfPTable tabel = new PdfPTable(3);

            tabel.addCell("From");
            tabel.addCell("Mesaj");
            tabel.addCell("Data");




            for(Message mesaj:lstMPdf)
            {
                tabel.addCell(mesaj.getUsername());
                tabel.addCell(mesaj.getMessage());
                tabel.addCell(mesaj.getData().toString());
            }

            document.add(tabel);

            if(!prietenFixat) {

                paragraph = new Paragraph("Prietenii");
                document.add(paragraph);

                tabel = new PdfPTable(2);

                tabel.addCell("Prieten");
                tabel.addCell("Data");

                for (PrietenDTO prietenie : lstPPdf) {
                    tabel.addCell(prietenie.getUsername());
                    tabel.addCell(prietenie.getData().toString());

                }

                document.add(tabel);
            }

            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void makePdf(MouseEvent mouseEvent) {
        addPdf();
    }
}
