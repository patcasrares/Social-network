package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import socialnetwork.domain.Message;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.util.*;
import java.util.stream.Collectors;

public class ConversatiiController extends Control {


    private SideBarController sbc;

    @Override
    public void parinte(SideBarController sbc)
    {
        this.sbc = sbc;
    }
    private Map<Long,String> mp = new HashMap<>();

    @FXML
    private BorderPane bp;

    private Set<String> conversatii = new HashSet<>();

    private  Utilizator U  ;
    @FXML
    private VBox vb;
    private MessageService srvM;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private CerereService srvC;

    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.srvM = srvM;
        this.srvU = srvU;
        this.U = U;
        this.srvP = srvP;
        this.srvC = srvC;
        load();
    }

    public void load() {
       // List<Message> lst = srvM.getConversatii(U.getId());
        conversatii.clear();
        vb.getChildren().clear();
        List<Message> lst = getPageDTO().getConversatii();
        lst = lst.stream()
                .sorted((x,y)->y.getData().compareTo(x.getData()))
        .collect(Collectors.toList());
        //if(lst.size()>0)
          //  return;
        for(Message m:lst)
        {
            //System.out.println(m.getData());
            Utilizator ut;
            List<Utilizator> utilizatori = new ArrayList<>();
            ut=m.getFrom();
            //ut=srvU.findOne(ut.getId());
            if(!ut.getId().equals(U.getId()))
                utilizatori.add(ut);
            List<Utilizator> to =m.getTo();
            for(Utilizator dest:to)
            {
                ut=dest;
                //ut=srvU.findOne(ut.getId());
                if(!ut.getId().equals(U.getId()))
                    utilizatori.add(ut);
            }
            addConvs(utilizatori);
        }





        /*for(int i=1;i<=10;i++)
        {
            Label z=new Label("convers"+"\t\t\t\t\t\t\t\t");
            //z.setTextFill(Color.web(colText));

            HBox b = new HBox(),bb=new HBox();
            Background unfocusBackground = new Background(new BackgroundFill(Color.web("white"), CornerRadii.EMPTY, Insets.EMPTY));
            b.setBackground(unfocusBackground);
            //b.setSize
            // z.setBackground(unfocusBackground);
            b.getChildren().add(z);
            b.getChildren().add(new Button("Reply"));
            bb.getChildren().addAll(new Label(""), b);
            vb.getChildren().add(bb);
            vb.getChildren().add(new Label(""));
        }*/
    }

    private void addConvs(List<Utilizator> utilizatori) {
        System.out.println("init mesaje");
        String str="Me";
        utilizatori = utilizatori.stream()
                .sorted((a,b)->{
                    return a.getId().compareTo(b.getId());
                })
                .collect(Collectors.toList());

        //if(1==1)
          //  return;

        for(Utilizator ut:utilizatori)
            if(!ut.getId().equals(U.getId())) {
                if(mp.get(ut.getId())==null)
                {
                    mp.put(ut.getId(),srvU.findOne(ut.getId()).getUsername());
                }
                str = str + "," + mp.get(ut.getId());
            }

        if(conversatii.contains(str))
            return;
        conversatii.add(str);

        adaugChat(str,utilizatori);

    }

    private void adaugChat(String str, List<Utilizator> utilizatori)
    {
        try
        {
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/ChatRoom.fxml"));

            Pane root = loader.load();
            vb.getChildren().add(root);
            ChatBox cc= loader.getController();

            cc.setText(str);
            cc.getButton().setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    showChat(U.getId(),utilizatori);
                }
            });
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    /*
    private void adaugChat(String str, List<Utilizator> utilizatori) {
        Button btn = new Button("Chat");

        Label z=new Label(str+"\t\t\t\t\t\t\t\t");
        //z.setTextFill(Color.web(colText));

        HBox b = new HBox(),bb=new HBox();
        Background unfocusBackground = new Background(new BackgroundFill(Color.web("white"), CornerRadii.EMPTY, Insets.EMPTY));
        b.setBackground(unfocusBackground);
        //b.setSize
        // z.setBackground(unfocusBackground);
        b.getChildren().add(z);
        b.getChildren().add(btn);
        bb.getChildren().addAll(new Label(""), b);
        vb.getChildren().add(bb);
        vb.getChildren().add(new Label(""));

        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                showChat(U.getId(),utilizatori);
            }
        });
    }*/

    public void showChat(Long id, List<Utilizator> utilizatori) {
        Parent root = null;
        ChatController cc = null;
        try
        {
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/Chat.fxml"));

            root = loader.load();
            cc = loader.getController();

            cc.setDTO(getPageDTO());
            //cc.parinte(this);

            cc.setDestinari(utilizatori);
            cc.initial(srvU.findOne(id), srvU, srvP, srvM, srvC);


        }
        catch(Exception e)
        {
            System.out.println(e);
            System.out.println("nu merge");
            System.out.println(e.getStackTrace());
        }
        sbc.showWindow(root);
        //bp.setCenter(root);

    }

    public void sendNewMessage(MouseEvent mouseEvent) {
        Parent root = null;
        CreateNewMessage cc = null;

        try
        {
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/NewMessage.fxml"));
            root = loader.load();
            cc = loader.getController();
            //cc.parinte(this);

            cc.initial(U, srvU, srvP, srvM, srvC);
            cc.setParent(this);

        }
        catch(Exception e)
        {
            System.out.println(e);
            System.out.println("nu merge");
            System.out.println(e.getStackTrace());
        }
        sbc.showWindow(root);
        //bp.setCenter(root);
    }

}
