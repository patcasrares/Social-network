package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import socialnetwork.domain.Cerere;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.util.List;

public class CereriUserController extends Control {

    private int count = 4;
    @FXML
    private Pagination pagination;
    private  Utilizator U=null;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;
    ObservableList<Cerere> modelCereri = FXCollections.observableArrayList();
    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U=U;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
        initialize();
    }

    //private TableView cereri;

    @FXML
    TableColumn<Cerere, Long> Recv;
    @FXML
    TableColumn<Cerere, String> Status;
    @FXML
    TableColumn<Cerere, String> Date;

    @FXML
    TableView<Cerere> cereri;

    public void initialize()
    {
        this.Recv.setCellValueFactory(new PropertyValueFactory<Cerere , Long>("Recv"));
        this.Status.setCellValueFactory(new PropertyValueFactory<Cerere , String>("Status"));
        this.Date.setCellValueFactory(new PropertyValueFactory<Cerere , String>("Date"));

        cereri.setItems(modelCereri);
        if(U!=null) {
           // modelCereri.setAll(srvC.cereri_trimise(U.getId()));
            super.creezTabel(pagination,srvC.cereri_trimise(U.getId()),count,modelCereri);

           /* int nrU = srvU.nrUtilizatori(First.getText(),Last.getText());
            int cntP= nrU / count;
            if( nrU%count>0)
                cntP++;
            pagination.setPageCount(cntP);
            pagination.setPageFactory((index)->{
                List<Utilizator> lstU = srvC.getAll(index,count);
                //add_butoane(lstU);
                modelCereri.setAll(lstU);
                return new AnchorPane();
            });*/
        }
    }


    public void setSrv(UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.srvU=srvU;
        this.srvP=srvP;
        this.srvM=srvM;
        this.srvC=srvC;

        initialize();
    }

    public void setUser(Utilizator U) {
        this.U=U;
        update();
    }

    private void update() {
        if(U==null)
            return;
        modelCereri.setAll(srvC.cereri_trimise(U.getId()));

    }


}
