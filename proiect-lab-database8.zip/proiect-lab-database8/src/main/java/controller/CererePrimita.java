package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.control.SkinBase;
import javafx.scene.layout.VBox;

public class CererePrimita {
    @FXML
    private Button Acp;

    @FXML
    private Button Res;

    @FXML
    private VBox aspect;

    @FXML
    private Label label;


    public Button getAcp()
    {
        return Acp;
    }

    public Button getRes()
    {
        return Res;
    }

    public VBox getAspect() {
        return aspect;
    }

    public void setText(String s) {
        label.setText(s);
    }
}
