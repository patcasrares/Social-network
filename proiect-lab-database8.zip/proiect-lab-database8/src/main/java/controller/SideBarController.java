package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;
import socialnetwork.domain.Eveniment;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.*;

import java.net.URL;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

public class SideBarController implements Initializable {


    private  Utilizator U;
    @FXML
    private AnchorPane ap;
    @FXML
    private BorderPane bp;

    @FXML
    private VBox notificari;

    private UtilizatorService srvU;
    private PrietenieService srvP;
    private CerereService srvC;
    private MessageService srvM;
    private Long id;
    private EvenimenteService srvE;
    private Parent userFriendsPage;
    private Parent cereriUseriPrimitePage;
    private Parent cereriUseriTrimisePage;
    private Parent chatPage;
    private Parent addFriendsPage;
    private Control auxiliar;
    private Control controlUser;
    private Control controlAddFriends;
    private Control controlUserPrimite;
    private Control controlChat;
    private Control controlCereriUseriTrimise;

    Map<String,Parent> mpFerestre = new HashMap<>();
    private PageDTO pageDTO;
    private Parent EvPage;
    private Parent CereriPage;
    private CereriNoi controlCereri;

    public void creeazaNotificari(List<Eveniment> lst)
    {
        notificari.getChildren().clear();
        lst.forEach(x->
        {
            //loadPage("/view/Notificare.fxml");

            int vf = 1;
            System.out.println("data eveniment "+x.getDate().compareTo(LocalDateTime.now()));
            if(x.getDate().compareTo(LocalDateTime.now())<=0)
                vf = 0;

            if(! (x.getDate().getDayOfMonth()==LocalDateTime.now().getDayOfMonth() &&
                    x.getDate().getMonth()==LocalDateTime.now().getMonth() &&
                    x.getDate().getYear()==LocalDateTime.now().getYear())) {
                        vf=0;
            }



            if (vf==1) {
                try {
                    FXMLLoader loader = new FXMLLoader();
                    loader.setLocation(getClass().getResource("/view/Notificare.fxml"));
                    AnchorPane root = (AnchorPane) loader.load();

                    // stage
                    Stage dialogStage = new Stage();
                    dialogStage.setTitle("Edit Message");
                    dialogStage.initModality(Modality.APPLICATION_MODAL);
                    Scene scene = new Scene(root);
                    dialogStage.setScene(scene);

                    NotificareController emtc = loader.getController();
                    emtc.setText("Veti participa la evenimentul  : " + x.getDescriere() + " la ora 20:30");
                    notificari.getChildren().add(root);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public void setSrvE(EvenimenteService srvE)
    {
        this.srvE = srvE;
    }

    public void sidebar(MouseEvent mouseEvent) {
        //loadPage("/view/sidebar.fxml");
        bp.setCenter(ap);
        creeazaNotificari(srvE.getNotificari(U.getId()));
    }

    private Parent loadPage(String s) {
        Parent root = null;
        Control cc = null;
        try
        {
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource(s));


            
            root = loader.load();
            cc = loader.getController();

            if (pageDTO == null)
            {
                System.out.println("nu nu nu nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn");
            }
            System.out.println("doamne");
            cc.setDTO(pageDTO);
            cc.parinte(this);

            cc.initial(U,srvU,srvP,srvM,srvC);

            cc.setSrvEvent(srvE);

            auxiliar = cc;

        }
        catch(Exception e)
        {
            System.out.println(e);
            System.out.println("nu merge");
            System.out.println(e.getStackTrace());
        }
        //cc.setStart(false);
        bp.setCenter(root);
        mpFerestre.put(s,root);


        //cc.setStart(false);
        return root;
    }

    public void CereriUserView(MouseEvent mouseEvent) {
        loadPage("/view/CereriUserView.fxml");
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void UserFriends(MouseEvent mouseEvent) {
        if(userFriendsPage == null) {
            userFriendsPage = loadPage("/view/UserView.fxml");
            controlUser = auxiliar;
        }
        else
            bp.setCenter(userFriendsPage);
    }

    public void AddFriends(MouseEvent mouseEvent) {

        if(addFriendsPage == null) {
            addFriendsPage = loadPage("/view/AdaugFriend.fxml");
            controlAddFriends = auxiliar;
        }
        else
            bp.setCenter(addFriendsPage);
    }

    public void initial(Long id, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.id=id;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;

        System.out.println("e ok");
        PageService pageService = new PageService(id,srvU,srvP,srvM,srvC,srvE);
        System.out.println("e okkkkkkkkkkkkkkkk");
        pageDTO = pageService.getDTO();
        U = pageDTO.getU();
        System.out.println("e okzzz");

        CereriUseriPrimiteView(null);

        CereriUseriTrimiseView(null);
        ChatView(null);
        UserFriends(null);
        AddFriends(null);
        CereriViewNou(null);



       // controlAddFriends.addFereastra(controlCereriUseriTrimise);
       // controlAddFriends.addFereastra(controlUser);

        //controlUserPrimite.addFereastra(controlUser);

        controlAddFriends.addFereastra(controlCereri);
        controlCereri.addFereastra(controlUser);

        controlCereri.addFereastra(controlAddFriends);


        creeazaNotificari(pageDTO.getNotificari());
        bp.setCenter(ap);

        //msg.appendText("ana are mere");
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    public void CereriUseriPrimiteView(MouseEvent mouseEvent) {
        if(cereriUseriPrimitePage == null) {
            cereriUseriPrimitePage = loadPage("/view/CereriUserPrimite.fxml");
            controlUserPrimite = auxiliar;
            CereriUserPrimiteController z =(CereriUserPrimiteController) auxiliar;

        }
        else
            bp.setCenter(cereriUseriPrimitePage);
    }

    public void ChatView(MouseEvent mouseEvent) {
        if(chatPage == null) {
            chatPage = loadPage("/view/Conversatii.fxml");
            controlChat = auxiliar;
        }
        else {
            ConversatiiController cc = (ConversatiiController)controlChat;
            cc.load();
            bp.setCenter(chatPage);
        }

    }

    public void CereriUseriTrimiseView(MouseEvent mouseEvent) {
        if(cereriUseriTrimisePage == null) {
            cereriUseriTrimisePage = loadPage("/view/CereriUseriTrimise.fxml");
            controlCereriUseriTrimise = auxiliar;
        }
        else
            bp.setCenter(cereriUseriTrimisePage);
    }

    public void RaportView(MouseEvent mouseEvent) {
        loadPage("/view/Raport.fxml");
    }

    public void AllView(MouseEvent mouseEvent) {
        loadPage("/view/AllView.fxml");
        auxiliar.setFerestre(mpFerestre);

    }

    public void EventsView(MouseEvent mouseEvent) {
        if(EvPage == null)
            EvPage =loadPage("/view/EventsView.fxml");
        else
            bp.setCenter(EvPage);
    }

    public void openRaport(Utilizator ut) {
        loadPage("/view/Raport.fxml");
        RaportController rap = (RaportController)auxiliar;
        rap.filter(ut);

    }

    public void showWindow(Parent root) {

        bp.setCenter(root);
    }

    public void CereriViewNou(MouseEvent mouseEvent) {
        if(CereriPage == null) {
            CereriPage = loadPage("/view/CereriNoi.fxml");
            controlCereri = (CereriNoi) auxiliar;
        }
        else
            bp.setCenter(CereriPage);
    }

    //@FXML
    //private TextArea msg;


}
