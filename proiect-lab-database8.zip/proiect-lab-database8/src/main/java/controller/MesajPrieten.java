package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;

public class MesajPrieten {

    @FXML
    private Label label;

    @FXML
    private MenuButton menu;

    public void setText(String str)
    {
        label.setText(str);
    }

    public MenuButton getMenu()
    {
        return menu;
    }


}
