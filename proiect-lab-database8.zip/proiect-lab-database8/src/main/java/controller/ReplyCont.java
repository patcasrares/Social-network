package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ReplyCont {

    @FXML
    private Label label;



    public void setText(String str)
    {
        label.setText(str);
    }

}
