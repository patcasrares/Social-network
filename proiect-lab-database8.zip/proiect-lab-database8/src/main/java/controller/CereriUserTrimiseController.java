package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import socialnetwork.domain.Cerere;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.util.List;

public class CereriUserTrimiseController extends Control{

    @Override
    public void restart()
    {
        if(U==null)
            return;
        System.out.println("restart");

        int nrU = srvC.nrCereri(U.getId(),0);
        if(getStart()==false)
            nrU = getPageDTO().getNrCereriTrimise();
        else
            nrU = srvC.nrCereri(U.getId(),0);
        int cntP= nrU / count;
        if( nrU%count>0)
            cntP++;
        pagination.setPageCount(cntP);
        System.out.println("revelion");
        pagination.setPageFactory((index)->{
            System.out.println(getStart());
            if(getStart()==false) {
                System.out.println("de ce");
                List<Cerere> lstU = srvC.cereri(U.getId(), index, count, 0);
                addButoane(lstU);
                modelCereri.setAll(lstU);
            }
            setStart(false);
            return new AnchorPane();
        });
        /*if(U!=null){
            List<Cerere> listCereri = srvC.cereri_trimise(U.getId());
            addButoane(listCereri);
            creezTabel(pagination,listCereri,count,modelCereri);
            //modelCereri.setAll(listCereri);
        }*/
    }

    @FXML
    private Pagination pagination;

    private int count=5;

    private Utilizator U=null;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;
    ObservableList<Cerere> modelCereri = FXCollections.observableArrayList();
    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U=U;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
        initializez();
    }

    //private TableView cereri;rare

    @FXML
    TableColumn<Cerere, Long> Sender;
    @FXML
    TableColumn<Cerere, String> Date;
    @FXML
    TableColumn<Cerere, Button> removeButton;

    @FXML
    TableView<Cerere> cereri;

    public void initializez()
    {
        this.Sender.setCellValueFactory(new PropertyValueFactory<Cerere , Long>("Recv"));
        this.Date.setCellValueFactory(new PropertyValueFactory<Cerere , String>("Date"));
        this.removeButton.setCellValueFactory(new PropertyValueFactory<Cerere , Button>("removeButton"));

        cereri.setItems(modelCereri);
        List<Cerere> trimise = getPageDTO().getCereriTrimise();
        addButoane(trimise);
        modelCereri.setAll(trimise);
       /* if(U!=null){
            List<Cerere> listCereri = srvC.cereri_trimise(U.getId());
            addButoane(listCereri);
            creezTabel(pagination,listCereri,count,modelCereri);
            //modelCereri.setAll(listCereri);
        }*/

        restart();


    }

    private void addButoane(List<Cerere> listCereri) {
        for (Cerere c : listCereri) {
            c.getRemoveButton().setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    srvC.stergere(new Tuple<Long, Long>(c.getSender(), c.getRecv()));
                    //modelCereri.setAll(srvC.cereri_trimise(U.getId()));
                    List<Cerere > lst = srvC.cereri_trimise(U.getId());
                    addButoane(lst);
                    creezTabel(pagination,lst,count,modelCereri);
                }
            });
        }
    }


    public void setSrv(UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.srvU=srvU;
        this.srvP=srvP;
        this.srvM=srvM;
        this.srvC=srvC;

        //initialize();
    }

    public void setUser(Utilizator U) {
        this.U=U;
        update();
    }

    private void update() {
        if(U==null)
            return;
        modelCereri.setAll(srvC.cereri_primite(U.getId()));

    }
}
