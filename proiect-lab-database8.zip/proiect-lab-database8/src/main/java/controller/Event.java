package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;

public class Event {

    @FXML
    private MenuButton menu;

    @FXML
    private Label label;

    public void setText(String descriere) {
        label.setText(descriere);
    }

    public MenuButton getMenuButton()
    {
        return menu;
    }
}
