package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

import javax.swing.text.html.ImageView;

public class Friend {

    @FXML
    private Label label;

    @FXML
    private Button Rem;

    @FXML
    private Button Istoric;

    @FXML
    private VBox aspect;

    public void setText(String str)
    {
        label.setText(str);
    }

    public Button getRem()
    {
        return Rem;
    }

    public Button getIstoric()
    {
        return Istoric;
    }

    public VBox getProfil()
    {
        return aspect;
    }


}
