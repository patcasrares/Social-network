package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Pagination;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import socialnetwork.domain.Cerere;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;
import socialnetwork.repository.database.RepoBaza;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CereriNoi extends Control{

    private int count =5;

    @Override
    public void restart()
    {
        creezListaTrimise();
    }



    @FXML
    private VBox vPrimite;

    @FXML
    private VBox vTrimise;

    @FXML
    private Pagination pPrimite;

    @FXML
    private Pagination pTrimise;

    private Utilizator U ;
    private CerereService srvC;
    private UtilizatorService srvU;
    private ArrayList<String> lstImagini;

    private void imaginiProfil() {
        lstImagini = new ArrayList<String>(Arrays.asList(
                "/images/cats.png",
                "/images/lion_96px.png",
                "/images/bear_96px.png",
                "/images/panda_96px.png",
                "/images/cat_profile_128px.png"
        ));
    }

    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U = U;
        this.srvC = srvC;
        this.srvU = srvU;

        imaginiProfil();

        creezCereri();
    }

    private void creezCereri() {

        creezListaTrimise();
        creezListaPrimite();
    }

    private void creezListaTrimise() {
        int nr = getPageDTO().getNrCereriTrimise();

        int nrP = nr/count;
        if(nr%count > 0)
            nrP++;

        pTrimise.setPageCount(nrP);

        pTrimise.setPageFactory(x->{
            List<Cerere> lst;
            if(getStart()==false)
            {
                lst = srvC.cereri(U.getId(), x, count, 0);
            }
            else
                lst = getPageDTO().getCereriTrimise();

            setStart(false);

            creezCereriTrimise(lst);
            return new Pane();
        });
    }

    private void creezCereriTrimise(List<Cerere> lst) {
        vTrimise.getChildren().clear();
        Collections.shuffle(lstImagini);
        int pz = 0;
        for(Cerere cerere:lst)
        {
            try {
                pz++;
                if(pz>=lstImagini.size())
                    pz = 0;
                FXMLLoader loader=new FXMLLoader();
                loader.setLocation(getClass().getResource("/view/CerereTrimisa.fxml"));


                Pane root = loader.load();

                CerereTrimisa cc = loader.getController();

                Utilizator ut = srvU.findOne(cerere.getRecv());
                cc.setText(ut.getUsername());

                cc.getRem().setOnAction(x->{
                    srvC.stergere(new Tuple<Long, Long>(cerere.getSender(), cerere.getRecv()));
                    int pag = pTrimise.getCurrentPageIndex();
                    creezListaTrimise();
                    pag = Math.min(pag,pTrimise.getPageCount()-1);
                    pTrimise.setCurrentPageIndex(pag);
                    updateFerestre();

                });

                Image image = new Image(getClass().getResourceAsStream(lstImagini.get(pz)));
                ImageView img = new ImageView(image);
                img.setFitHeight(40);
                img.setFitWidth(40);
                cc.getAspect().getChildren().add(img);

                HBox hb = new HBox();
                hb.getChildren().add(root);
                root.setMaxWidth(50);
                hb.setPrefWidth(50);
                vTrimise.getChildren().add(hb);
            }
            catch(Exception e)
            {

            }
        }
    }


    private void creezListaPrimite() {
        //List<Cerere> lst = getPageDTO().getCereriPrimite();
        int nr = getPageDTO().getNrCereriPrimite();

        int nrP = nr/count;
        if(nr%count > 0)
            nrP++;

        pPrimite.setPageCount(nrP);

        pPrimite.setPageFactory(x->{
            List<Cerere> lst;
            if(getStart()==false)
            {
                lst = srvC.cereri(U.getId(), x, count, 1);
            }
            else
                lst = getPageDTO().getCereriPrimite();

            setStart(false);

            creezCereriPrimite(lst);
            return new Pane();
        });

    }

    private void creezCereriPrimite(List<Cerere> lst) {
        vPrimite.getChildren().clear();
        Collections.shuffle(lstImagini);
        int pz = 0;
        for(Cerere cerere:lst)
        {
            try {
                pz++;
                if(pz>=lstImagini.size())
                    pz = 0;
                FXMLLoader loader=new FXMLLoader();
                loader.setLocation(getClass().getResource("/view/CererePrimita.fxml"));

                Pane root = loader.load();
                HBox hb = new HBox();
                hb.getChildren().add(root);
                root.setMaxWidth(50);
                hb.setPrefWidth(50);
                vPrimite.getChildren().add(hb);

                CererePrimita cc = loader.getController();

                cc.getAcp().setOnAction(x->{
                    srvC.accepta(cerere.getRecv(), cerere.getId());
                    updateFerestre();
                    int pag = pPrimite.getCurrentPageIndex();
                    creezListaPrimite();
                    pag = Math.min(pag,pPrimite.getPageCount()-1);
                    pPrimite.setCurrentPageIndex(pag);

                });

                cc.getRes().setOnAction(x->{
                    srvC.refuza(cerere.getRecv(), cerere.getId());
                    int pag = pPrimite.getCurrentPageIndex();
                    creezListaPrimite();
                    pag = Math.min(pag,pPrimite.getPageCount()-1);
                    pPrimite.setCurrentPageIndex(pag);

                });

                Utilizator ut = srvU.findOne(cerere.getSender());
                cc.setText(ut.getUsername());


                Image image = new Image(getClass().getResourceAsStream(lstImagini.get(pz)));
                ImageView img = new ImageView(image);
                img.setFitHeight(40);
                img.setFitWidth(40);
                cc.getAspect().getChildren().add(img);
            }
            catch(Exception e)
            {

            }
        }
    }
}
