package controller;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import socialnetwork.domain.Message;
import socialnetwork.domain.ReplyMessage;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import javax.swing.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatController extends Control {


   // private Label lsb = new Label();
    private Pane pane;
    private HBox zz = new HBox();
    @FXML
    private HBox hreply;

    private List<Node> bx = new ArrayList<>();

    private VBox mesajChat = new VBox();

    @FXML
    private Label ChatName;

    @FXML
    private Label TextReply;

    @FXML
    private VBox vb;

    @FXML
    private ScrollPane scrollPane;

    private Message MesajCurent = null;


    private List<Utilizator> lista;

    private Utilizator U;
    private UtilizatorService srvU;
    private MessageService srvM;
    private PrietenieService srvP;

    private CerereService srvC;
    private Message MesajReply;
    private Map<Long,Utilizator> prieteni = new HashMap<>();


    public void reload()
    {
        setDestinari(lista);
        bx.clear();
        vb.getChildren().clear();
        //bx.getChildren().clear();
        scrollPane.setVvalue(1.0);

        List<Utilizator> users = new ArrayList<>();
        users.add(U);
        for(Utilizator ut:lista)
        {
            users.add(ut);
        }
        List<Message> mesaje = srvM.getMsg(users);
        System.out.println("gata");

        for(Message m:mesaje)
        {
            adaugMesaj(m);


            //System.out.println("hai odata");

        }

       // vb.getChildren().add(bx);
    }

    private void adaugMesaj(Message m) {
        MesajCurent = m;
        //System.out.println(m.getId());
        String str="";
        Utilizator ut = m.getFrom();

        //ut = srvU.findOne(ut.getId());
        if(ut.getId().equals(U.getId())) {
            str = "";
            if(m.getReply()!=null)
            {
                addReplyFromMe(m.getReply());
            }
            str+=m.getMessage();
            addFromMe(str);
        }
        else {
            if(m.getReply()!=null)
            {
                addReplyFromOthers(m.getReply());
            }
            str = getUsername(ut.getId()) + ": ";
            str+=m.getMessage();
            addFromOthers(str);

        }
    }

    private String getUsername(Long id) {
        Utilizator ut = prieteni.get(id);
        return ut.getUsername();
    }

    private void addReplyFromMe(Message m) {
        //Message m = srvM.findOne(id);
        //System.out.println(m.getMessage());
        //addMsg(m.getMessage(),"\t\t\t\t\t\t\t\t\t\t","#0e008c","white",true,false);
        addBoxReply("\t\t\t\t\t\t\t\t\t\t\t",m.getMessage());
    }

    private void addBoxReply(String s,String mesaj) {
        mesajChat = new VBox();
        try
        {
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/Reply.fxml"));

            Pane root = loader.load();
            ReplyCont cc = loader.getController();
            cc.setText(mesaj);
            root.setMaxWidth(10);
            //cc.setText();
            HBox hb = new HBox();
            hb.getChildren().add(new Label(s));
            hb.getChildren().add(root);
            mesajChat.getChildren().add(hb);
            //vb.getChildren().add(hb);
            //vb.setSpacing(0);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    private void addReplyFromOthers(Message m) {
        //Message m = srvM.findOne(id);
       // System.out.println(m.getMessage());
        //addMsg(m.getMessage(),"","#0e008c","white",true,false);
        addBoxReply("",m.getMessage());
    }


    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U = U;
        this.srvU =srvU;
        this.srvM = srvM;
        this.srvP = srvP;
        this.srvC = srvC;
       // creezSpatiu();
        reload();
        setDestinari(lista);
    }

    private void creezSpatiu() {
        zz = new HBox();
        try {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/Spatiu.fxml"));

            pane = loader.load();
            zz.getChildren().add(pane);
        }
        catch(Exception e)
        {

        }
    }

    @FXML
    private TextArea TextMesaj;



    private void addFromMe(String s) {
     /*   addMsg(s,"\t\t\t\t\t\t\t\t\t\t","#0078FF","white",false,true);
        scrollPane.setVvalue(1.0);
        scrollPane.setHvalue(1.0 );

      */

        try
        {
           // vb.getChildren().remove(zz);
           // creezSpatiu();
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/MesajMe.fxml"));

            Pane root = loader.load();
            HBox hb = new HBox();
            hb.getChildren().add(new Label("\t\t\t\t\t\t\t\t\t\t\t"));
            hb.getChildren().add(root);
            mesajChat.getChildren().add(hb);
            vb.getChildren().add(mesajChat);
            MesajMe cc= loader.getController();

            cc.setText(s);
            root.setMaxWidth(10);

            mesajChat = new VBox();

            scrollPane.setVvalue(1.0);
            scrollPane.setHvalue(1.0);
            //vb.getChildren().add(zz);
            //vb.setSpacing(0);
            //cc.setText();

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

    }

    private void addFromOthers(String s) {
        //addMsg(s,"","#ded9d9","black",false,false);
        //scrollPane.setVvalue(1.0);
        //scrollPane.setHvalue(1.0 );
        try
        {
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/MesajPrieten.fxml"));

            Pane root = loader.load();
            mesajChat.getChildren().add(root);
            vb.getChildren().add(mesajChat);
            MesajPrieten cc= loader.getController();

            cc.setText(s);
            root.setMaxWidth(10);

            MenuButton menu = cc.getMenu();
            menu.getItems().clear();

            MenuItem menuItem1 = new MenuItem("Reply to one");
            MenuItem menuItem2 = new MenuItem("Reply to all");

            if(prieteni.size()>1)
                menu.getItems().add(menuItem2);

            menu.getItems().add(menuItem1);


            Message msg = MesajCurent;


            menuItem2.setOnAction(x->{
                hreply.getChildren().clear();
                addReply(msg);
            });

            menuItem1.setOnAction(x->{
                hreply.getChildren().clear();
                List<Utilizator> user = new ArrayList<>();
                user.add(msg.getFrom());
                setDestinari(user);
                reload();
                addReply(msg);
            });

            mesajChat = new VBox();
            //cc.setText();

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

    }

    private int numar=0;
    private void addMsg(String s, String s1,String col,String colText,boolean reply,boolean fromMe) {

        //List<Label> zzzz = new ArrayList<>();
        //vb.getChildren().addAll(zzzz);
        //scrollPane.setVvalue(1.0);
        //vb.getChildren().add(new Label(""));
        Label z=new Label(s+"  ");
        z.setTextFill(Color.web(colText));

        HBox b = new HBox(),bb=new HBox();
        Background unfocusBackground = new Background(new BackgroundFill(Color.web(col), CornerRadii.EMPTY, Insets.EMPTY));
        b.setBackground(unfocusBackground);
        //b.setSize
        // z.setBackground(unfocusBackground);
        b.getChildren().add(z);
        if(!reply&&!fromMe) {
            Button btn1 = new Button("Reply");
            Button btn2 = new Button("Reply All");
            b.getChildren().add(btn1);
            b.getChildren().add(btn2);

            Message msg = MesajCurent;

            btn2.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    addReply(msg);
                }
            });

            btn1.setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    List<Utilizator> user = new ArrayList<>();
                    user.add(msg.getFrom());
                    setDestinari(user);
                    reload();
                    addReply(msg);
                }
            });
        }
        else {
            //z = new Label(s+"\n\n\n\n");
            b.getChildren().remove(z);
            VBox nouVb = new VBox();
            b.getChildren().add(nouVb);
            nouVb.getChildren().add(z);
            nouVb.getChildren().add(new Text(""));
            //nouVb.setMaxSize(50,50);
            //z.setMaxHeight(200);
            //b.setPrefHeight(500);
            //b.setPrefWidth(500);


        }
        bb.getChildren().addAll(new Label(s1), b);
        //bx.getChildren().add(bb);
        vb.getChildren().add(bb);
        if(!reply)
            vb.getChildren().add(new Label(""));


        numar++;
        //System.out.println("adaugat "+numar);
        //vb.getChildren().add(new Label(""));
       // scrollPane.setVvalue(0);
        //scrollPane.setVvalue(1.0);
        //scrollPane.setHvalue(1.0 );



    }

    private void addReply(Message msg) {
        //////////////TextReply.setText("Reply: "+msg.getMessage());
        Label lb = new Label("Reply: "+msg.getMessage());
        lb.setStyle("-fx-text-fill:  wheat ;-fx-font-weight: bold ; -fx-font-size: 17px");
        Button btn = new Button("");
        btn.setStyle("-fx-background-color: transparent");
        Image image = new Image(getClass().getResourceAsStream("/images/LX.png"));
        ImageView img=new ImageView(image);
        img.setFitHeight(20);
        img.setFitWidth(20);
        btn.setGraphic(img);
        btn.setOnAction(x->{
                hreply.getChildren().clear();
            MesajReply = null;
        });
        hreply.getChildren().addAll(lb,btn);


        MesajReply = msg;
    }


    public void setDestinari(List<Utilizator> utilizatori) {
        this.lista = utilizatori;
        prieteni.clear();
        if(srvU==null)
            return;
        for(Utilizator ut:utilizatori) {
            Long id = ut.getId();
            prieteni.put(id, srvU.findOne(id));
        }

        setTitlu();
    }

    private void setTitlu() {
        String str="Me";
        for(Utilizator u:lista)
        {
            str+=userStr(u.getId());
        }
        ChatName.setText(str);

    }

    private String userStr(Long id) {
        Utilizator ut = srvU.findOne(id);
        return ","+ut.getUsername();
    }


    public void trimitere(MouseEvent mouseEvent) {
        vb.getChildren().remove(pane);
        String s=TextMesaj.getText();
        System.out.println(s);
        if(s.equals(""))
            return;
        TextReply.setText("");
        TextMesaj.setText("");

        hreply.getChildren().clear();

        Message message;
        if(MesajReply==null)
            message = new Message(U,lista,s);
        else
        {
            ReplyMessage messageR = new ReplyMessage(U,lista,s);
            messageR.setReply(MesajReply);
            message = messageR;

        }
        srvM.addMessage(message);
        MesajReply = null;
        adaugMesaj(message);
        List<Message> lstM =getPageDTO().getConversatii();
        lstM.add(message);
        getPageDTO().setConversatii(lstM);
        //vb.getChildren().add(pane);
        scrollPane.setVvalue(1.0);
        scrollPane.setHvalue(1.0);

        //addFromMe(s);
    }
}
