package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class ChatUser {

    @FXML
    private Label label;

    @FXML
    private VBox profil;

    @FXML
    private Button buton;

    public Button getButon()
    {
        return buton;
    }

    public void setText(String s)
    {
        label.setText(s);
    }

    public VBox getProfil()
    {
        return profil;
    }
}
