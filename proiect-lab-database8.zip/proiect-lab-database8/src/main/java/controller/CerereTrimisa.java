package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class CerereTrimisa {

    @FXML
    private Label label;

    @FXML
    private Button Rem;

    @FXML
    private VBox aspect;

    public void setText(String s)
    {
        label.setText(s);
    }

    public Button getRem()
    {
        return Rem;
    }

    public VBox getAspect(){
        return aspect;
    }


}
