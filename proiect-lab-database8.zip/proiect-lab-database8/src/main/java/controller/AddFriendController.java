package controller;

import com.sun.javafx.fxml.BeanAdapter;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.util.Callback;
import socialnetwork.MessageAlert;
import socialnetwork.domain.UserDTO;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class AddFriendController extends Control {

    @Override
    public void restart()
    {
        U = srvU.findOne(U.getId());
        First.setText("A");
        First.setText("");

    }

    @FXML
    private Pagination pagination;

    @FXML
    private VBox boxUser;

    private Utilizator U ;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;

    private int count = 4;

    private UserController principal;


    List<Utilizator> lstUsers;

    ObservableList<Utilizator> modelUser = FXCollections.observableArrayList();
    private List<String> lstImagini;


    public void setPrincipal(UserController principal)
    {
        this.principal=principal;
    }




    private void add_butoane(List<Utilizator> lst) {
        for(Utilizator f:lst)
        {
            Image image = new Image(getClass().getResourceAsStream("/images/add.png"));
            ImageView img=new ImageView(image);
            img.setFitHeight(20);
            img.setFitWidth(20);
            f.getAddBtn().setGraphic(img);
            f.getAddBtn().setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    add_friend(f);
                }
            });
        }
    }

    private void add_friend(Utilizator selected) {
        try
        {
            boolean b=srvC.adaug(U.getId(), selected.getId());
            if(b==true) {
                MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "add friend", "ai acceptat prietenia");

            }
            else
                MessageAlert.showMessage(null,Alert.AlertType.INFORMATION,"add friend","ai trimis cererea");
            System.out.println("cristian");
            updateFerestre();
           // U=srvU.findOne(U.getId());
            //principal.setU(U);
            //modelUser.setAll(U.getFriends());
        }
        catch (Exception e)
        {
            MessageAlert.showErrorMessage(null,e.toString());
            //System.out.println(e);
        }
    }

    public void sdfs(Object i)
    {

    }
    private void handlePrieten() {
        sdfs(new Long(1));
        if(getStart() == true)
            return;


       // Predicate<Utilizator> p1 = ut -> ut.getFirstName().startsWith(First.getText());
        //Predicate<Utilizator> p2 = n -> n.getLastName().startsWith(Last.getText());

       
        
        int nrU = srvU.nrUtilizatori(First.getText());
        int cntP= nrU / count;
        if( nrU%count>0)
            cntP++;
        U = srvU.findOne(U.getId());
        pagination.setPageCount(cntP);
        pagination.setPageFactory(index->{
            List<Utilizator> lstU = srvU.getAll(index,count,First.getText());
            List<UserDTO> sol = turnDTO(lstU);
            creezListUser(sol);
            return new AnchorPane();
        });

    }

    public void setUser(Utilizator U) {
        this.U = U;
        System.out.println("setat "+U);

    }

    @FXML
    TextField First;
    @FXML
    TextField Last;




    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U=U;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;

        creezImagini();

        creezViewNou();

        First.textProperty().addListener(c -> handlePrieten());

    }

    private void creezImagini() {
        lstImagini =
                new ArrayList<String>( Arrays.asList(
                        "/images/cats.png",
                        "/images/lion_96px.png",
                        "/images/bear_96px.png",
                        "/images/panda_96px.png",
                        "/images/cat_profile_128px.png"
                ) );
    }

    private void creezViewNou() {
        int nrU = getPageDTO().getNrUser();

        if(getStart()==false) {
            U = srvU.findOne(U.getId());
            nrU = srvU.nrUtilizatori();
        }

        int nrP = nrU/count;
        if(nrU%count>0)
            nrP++;
        System.out.println("ddddddddddddddddddddddddddddddddddddd "+nrU+" "+ nrP);

        pagination.setPageCount(nrP);

        pagination.setPageFactory(x ->{

            List<UserDTO> lst = obtineDTO(x);
            setStart(false);
            creezListUser(lst);

            return new Pane();
        });
    }

    private void creezListUser(List<UserDTO> lst) {
        int pz = 0;
        boxUser.getChildren().clear();
        Collections.shuffle(lstImagini);
        for(UserDTO ut: lst)
        {
            pz++;
            if(pz==lstImagini.size()) {
                pz = 0;
            }
            try {
                //System.out.println("Imagine Rares "+pz);
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/view/AddFriend.fxml"));
                Pane root = loader.load();

                boxUser.getChildren().add(root);

                AddFriend fr = loader.getController();

                fr.setText(ut.getUsername() );



                fr.getButon().setText(ut.getStatus());

                if(!ut.getStatus().equals("Trimite cerere"))
                {
                    fr.getButon().setStyle("-fx-background-color:  #4d4dff");
                }
                else
                    fr.getButon().setOnAction(x->{
                        srvC.request(U.getId(),ut.getId());
                        updateFerestre();
                        fr.getButon().setText("Cerere trimisa");
                        fr.getButon().setStyle("-fx-background-color:  #4d4dff");
                    });

                Image image = new Image(getClass().getResourceAsStream(lstImagini.get(pz)));
                ImageView img=new ImageView(image);
                img.setFitHeight(53);
                img.setFitWidth(53);

                fr.getProfil().getChildren().add(img);


            }
            catch(Exception e){

            }
        }
    }

    private List<UserDTO> obtineDTO(int  pag) {
        if(getStart()==true) {

            return getPageDTO().getLstDTO();
        }


        return turnDTO(srvU.getAll(pag,count));
    }

    private List<UserDTO> turnDTO(List<Utilizator> users) {
        List<UserDTO> lst = new ArrayList<>();
        for(Utilizator ut2:users) {
            Utilizator ut = srvU.findOne(ut2.getId());
            UserDTO udt = new UserDTO(ut);

            if(U.getFriends().contains(ut))
                udt.setStatus("Prieteni");
            else {
                if (srvC.exista(U.getId(), ut.getId())) {
                    udt.setStatus("Cerere trimisa");
                }
            }
            if(U.getId().equals(ut.getId()))
                udt.setStatus("Your username");
            lst.add(udt);

        }
        return lst;
    }


    public void handleAdd(ActionEvent actionEvent) {
    }
}
