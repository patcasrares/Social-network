package controller;

import socialnetwork.domain.*;

import java.util.List;
import java.util.Set;

public class PageDTO {
    private  Utilizator U;

    //private boolean start ;

    private int nrUser;
    private List<Utilizator> lstU;

    private int nrCereriPrimite;
    private List<Cerere> cereriPrimite;

    private int nrCereriTrimise;
    private List<Cerere> cereriTrimise;
    private int nrEvenimenteActive;
    private int nrEvenimente;
    private List<Eveniment> evenimente;
    private List<Message> mesaje;
    private List<UserDTO> lstDTO;
    private List<Eveniment> lstE;
    private Set<Long> idAbonari;

    public int getNrCereriTrimise()
    {
        return nrCereriTrimise;
    }

    public void setNrCereriTrimise(int nrCereriTrimise)
    {
        this.nrCereriTrimise = nrCereriTrimise;
    }


    public void setCereriTrimise(List<Cerere> cereriTrimise)
    {
        this.cereriTrimise = cereriTrimise;
    }



    public List<Cerere> getCereriTrimise()
    {
        return cereriTrimise;
    }

    public int getNrCereriPrimite()
    {
        return nrCereriPrimite;
    }

    public void setNrCereriPrimite(int nrCereriPrimite)
    {
        this.nrCereriPrimite = nrCereriPrimite;
    }


    public List<Cerere> getCereriPrimite()
    {
        return cereriPrimite;
    }

    public void setCereriPrimite(List<Cerere> cereriPrimite)
    {
        this.cereriPrimite = cereriPrimite;
    }

    public int getNrUser()
    {
        return nrUser;
    }

    public void setNrUser(int nrUser)
    {
        this.nrUser = nrUser;
    }

    public List<Utilizator> getLstU()
    {
        return lstU;
    }


    public void setLstU(List<Utilizator> lstU)
    {
        this.lstU = lstU;
    }

    public Utilizator getU() {
        return U;
    }

    public void setU(Utilizator U) {
        this.U = U;
    }

    public void setNrEvActive(int nrEvenimenteActive) {
        this.nrEvenimenteActive = nrEvenimenteActive;
    }

    public void setNrEv(int nrEvenimente) {
        this.nrEvenimente = nrEvenimente;
    }

    public void setEvenimente(List<Eveniment> all) {
        this.evenimente = all;
    }

    public int getNrEvActive() {
        return nrEvenimenteActive;
    }

    public int getNrEv() {
        return nrEvenimente;
    }

    public List<Eveniment> getEvenimente() {
        return evenimente;
    }

    public List<Message> getConversatii() {

        return mesaje;
    }

    public void setConversatii(List<Message> conversatii) {
        this.mesaje = conversatii;
    }

    public void setLstDTO(List<UserDTO> lstDTO) {
        this.lstDTO = lstDTO;
    }

    public List<UserDTO> getLstDTO() {
        return lstDTO;
    }

    public List<Eveniment> getNotificari() {
        return lstE;
    }

    public void setNotificari(List<Eveniment> notificari) {
        lstE = notificari;
    }

    public Set<Long> getAbonari() {
        return idAbonari;
    }

    public void setAbonari(Set<Long> abonari) {
        idAbonari = abonari;
    }
}

