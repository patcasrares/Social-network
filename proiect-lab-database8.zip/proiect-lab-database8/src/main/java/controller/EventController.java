package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import socialnetwork.MessageAlert;
import socialnetwork.domain.Eveniment;
import socialnetwork.domain.Message;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class EventController extends Control {

    @FXML
    private Pagination pagination;

    @FXML
    private TextField descriereEv;

    @FXML
    private DatePicker dateEv;

    @FXML
    private VBox boxEvent;



    ObservableList<Eveniment> modelEvent = FXCollections.observableArrayList();

    private Utilizator U ;
    private EvenimenteService srv;
    private List<Eveniment> lstEvent;
    private int numarEvenimente;

    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U = U;
    }

    @Override
    public void setSrvEvent(EvenimenteService srv)
    {
        this.srv = srv;
        createViewNou();
    }

    private void createViewNou() {
        int nrU = getPageDTO().getNrEvActive();
        if ( getStart() == false)
            nrU = srv.nrEvenimenteActive();

        numarEvenimente = getPageDTO().getNrEv();

        if ( getStart() == false)
            numarEvenimente = srv.nrEvenimente();

        int cntP = nrU/count;
        if(nrU % count > 0)
            cntP++;

        pagination.setPageCount(cntP);
        pagination.setPageFactory((index)->{
            if(getStart() == false) {
                lstEvent = srv.getAll(index, count);
                //System.out.println("nu e bine frate");
            }
            else {
                lstEvent = getPageDTO().getEvenimente();
                init_abonari();
            }

            createLista(lstEvent);
            setStart(false);
            return new AnchorPane();
        });


    }

    Set<Long> idAbonari;
    Set<Long> idNotificari = new HashSet<>();

    private void init_abonari() {
        idAbonari = getPageDTO().getAbonari();
        List<Eveniment> lst = getPageDTO().getNotificari();

        for(Eveniment ev:lst)
            idNotificari.add(ev.getId());

    }

    private void createLista(List<Eveniment> lst) {
        System.out.println("vyghusjiokpaihuygvfytdsugahjiOKUYGDVSUHAI");
        System.out.println(lst.size());

        boxEvent.getChildren().clear();
        for(Eveniment ev:lst)
        {
            try {
                //System.out.println("Imagine Rares " + pz);
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/view/Event.fxml"));
                Pane root = loader.load();
                VBox hb = new VBox();
                hb.getChildren().add(root);

                boxEvent.getChildren().add(hb);

                Event cc = loader.getController();
                DateTimeFormatter format = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                String dat = ev.getDate().format(format);

                cc.setText(ev.getDescriere()+" in data de "+dat);

                MenuButton menuButton = cc.getMenuButton();

                menuButton.getItems().clear();

                MenuItem menuItem1 = new MenuItem("Abonare cu notificare ");
                MenuItem menuItem2 = new MenuItem("Abonare fara notificare");
                MenuItem menuItem3 = new MenuItem("Dezabonare");



                root.setMaxWidth(10);
                menuButton.getItems().add(menuItem1);
                menuButton.getItems().add(menuItem2);
                menuButton.getItems().add(menuItem3);

                menuItem1.setStyle("-fx-text-fill: black");
                menuItem2.setStyle("-fx-text-fill: black");
                menuItem3.setStyle("-fx-text-fill: black");

                menuItem1.setOnAction(x->{
                    menuButton.setText("Notificat");
                    try {
                        srv.abonare(ev.getId(), U.getId());
                    }
                    catch(Exception e)
                    {

                    }

                    try {
                        srv.notificare(ev.getId(),U.getId());
                    }
                    catch(Exception e)
                    {

                    }

                    idAbonari.add(ev.getId());
                    idNotificari.add(ev.getId());

                    createViewNou();
                    /*srv.abonare(ev.getId(),U.getId());
                    srv.notificare(ev.getId(),U.getId());

                    createViewNou();*/
                });
                menuItem2.setOnAction(x->{
                    menuButton.setText("Abonat");

                    try {
                        srv.notNotificare(ev.getId(), U.getId());
                    }
                    catch(Exception e)
                    {
                    }
                    idNotificari.remove(ev.getId());

                    try {
                        srv.abonare(ev.getId(),U.getId());
                    }
                    catch(Exception e)
                    {

                    }
                    idAbonari.add(ev.getId());
                    createViewNou();
                    /*
                    srv.abonare(ev.getId(),U.getId());

                     */
                });
                menuItem3.setOnAction(x->{
                    menuButton.setText("nu esti abonat");
                    try {
                        srv.notNotificare(ev.getId(), U.getId());
                    }
                    catch(Exception e)
                    {
                    }
                    srv.dezabonare(ev.getId(), U.getId());

                    idAbonari.remove(ev.getId());
                    idNotificari.remove(ev.getId());

                    createViewNou();
                    /*
                    srv.dezabonare(ev.getId(),U.getId());
                   // srv.remNotificare(ev.getId(),U.getId());

                     */
                });

                if(idNotificari.contains(ev.getId())) {
                    menuButton.setText("Notificat");
                    menuButton.getItems().remove(menuItem1);

                }
                else
                    if(idAbonari.contains(ev.getId())) {
                        menuButton.setText("Abonat");
                        menuButton.getItems().remove(menuItem2);
                    }
                    else
                        menuButton.getItems().remove(menuItem3);





            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    private void load() {
        abonari = srv.getAbonari(U.getId());
        lstEvent = srv.getAll();
        addButoane();
        modelEvent.setAll(lstEvent);

        ///super.creezTabel(pagination,lstEvent,4,modelEvent);
        creareTabel();

        //tableViewEvents.setItems(modelEvent);
    }

    private int count = 3;

    private void creareTabel() {
        int nrU = getPageDTO().getNrEvActive();
        if ( getStart() == false)
            nrU = srv.nrEvenimenteActive();

        numarEvenimente = getPageDTO().getNrEv();

        if ( getStart() == false)
            numarEvenimente = srv.nrEvenimente();
        System.out.println("EVVVVVVVVVV"+nrU);

        int cntP= nrU / count;
        if( nrU%count>0)
            cntP++;
        pagination.setPageCount(cntP);
        pagination.setPageFactory((index)->{
            if(getStart() == false) {
                lstEvent = srv.getAll(index, count);
                System.out.println("nu e bine frate");
            }
            else
                lstEvent = getPageDTO().getEvenimente();

            addButoane();
            modelEvent.setAll(lstEvent);
            setStart(false);
            return new AnchorPane();
        });
    }

    private Set<Long> abonari = new HashSet<>();

    private void addButoane() {
        System.out.println(abonari);
        for(Eveniment ev:lstEvent)
        {
            modificButton(ev.getAbonare(),"/images/add.png");
            if (LocalDateTime.now().compareTo(ev.getDate()) >= 0) {
                modificButton(ev.getAbonare(),"/images/stop.jpg");
            }

            if (abonari.contains(ev.getId())) {
                modificButton(ev.getAbonare(),"/images/LX.png");
                ev.getAbonare().setText("Dezabonare");
            }

            ev.getAbonare().setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {

                    if (LocalDateTime.now().compareTo(ev.getDate()) >= 0) {
                        modificButton(ev.getAbonare(),"/images/stop.jpg");
                        return;
                    }

                    if (!abonari.contains(ev.getId())) {
                        abonari.add(ev.getId());
                        modificButton(ev.getAbonare(),"/images/LX.png");
                        ev.getAbonare().setText("Dezabonare");
                        srv.abonare(ev.getId(),U.getId());
                    } else {
                        abonari.remove(ev.getId());
                        modificButton(ev.getAbonare(),"/images/add.png");
                        ev.getAbonare().setText("Abonare");
                        srv.dezabonare(ev.getId(),U.getId());
                    }

                }
            });
        }
    }

    private void modificButton(Button abonare, String s) {
        Image image = new Image(getClass().getResourceAsStream(s));
        ImageView img = new ImageView(image);
        img.setFitHeight(20);
        img.setFitWidth(20);
        abonare.setGraphic(img);
    }

    public void adaugEvent(MouseEvent mouseEvent) {
        String descriere = descriereEv.getText();
        LocalDate auxDate=dateEv.getValue();
        System.out.println(auxDate);
        LocalDateTime data =null;
        if(auxDate!=null)
            data=LocalDateTime.of(auxDate.getYear(),auxDate.getMonth(),auxDate.getDayOfMonth(),20,30,00);

        Eveniment ev = new Eveniment(descriere,data);
        ev.setId(new Long(numarEvenimente + 1));
        numarEvenimente++;

        try
        {
            srv.addEvent(ev);
            //lstEvent.add(ev);
            //addButoane();
            //modelEvent.setAll(lstEvent);
           /// super.creezTabel(pagination,lstEvent,4,modelEvent);
            createViewNou();
            MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "EVENT", "eveniment adaugat");
        }
        catch(Exception e)
        {
            MessageAlert.showErrorMessage(null,e.getMessage());
        }

    }
}
