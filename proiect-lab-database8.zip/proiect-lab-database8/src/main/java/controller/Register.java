package controller;

import javafx.animation.Interpolator;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import socialnetwork.domain.Utilizator;
import socialnetwork.domain.validators.ValidationException;
import socialnetwork.service.*;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Register {

    @FXML
    private Label lb1;

    @FXML
    private Label lb2;

    @FXML
    private Label lb3;

    @FXML
    private Label lb4;

    @FXML
    private Label lb5;

    @FXML
    private Label lb6;


    @FXML
    private TextField FirstName;

    @FXML
    private TextField LastName;

    @FXML
    private TextField Email;

    @FXML
    private TextField Username;

    @FXML
    private PasswordField Pass;

    @FXML
    private PasswordField CPass;



    @FXML
    private AnchorPane anchorPane;
    private CerereService srvC;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private MessageService srvM;
    private EvenimenteService srvE;

    public void CreateLogin(MouseEvent mouseEvent) throws Exception{
        FXMLLoader loader=new FXMLLoader();
        loader.setLocation(getClass().getResource("/view/Login.fxml"));

        Parent root = loader.load();
        LoginController register = loader.getController();
        register.setSrvE(srvE);
        register.initial(srvU,srvP,srvM,srvC);

        Scene loginScene = anchorPane.getScene();
        root.translateYProperty().set(loginScene.getHeight());
        StackPane rootPane = (StackPane)loginScene.getRoot();
        rootPane.getChildren().add(root);
        //rootPane.getChildren().remove(anchorPane);
        Timeline timeline = new Timeline();

        KeyValue keyValue=new KeyValue(root.translateYProperty(),0, Interpolator.EASE_IN);
        KeyFrame keyFrame=new KeyFrame(Duration.seconds(1),keyValue);

        timeline.getKeyFrames().add(keyFrame);


        timeline.play();

        timeline.setOnFinished((ActionEvent event2)->
        {
            rootPane.getChildren().remove(anchorPane);
        });

    }

    public void CreateAccount(MouseEvent mouseEvent) {
        lb1.setText("");
        lb2.setText("");
        lb3.setText("");
        lb4.setText("");
        lb5.setText("");
        lb6.setText("");
        String firstname = FirstName.getText();
        String lastname = LastName.getText();
        String email = Email.getText();
        String username = Username.getText();
        String password = Pass.getText();
        String password2 = CPass.getText();

        int vf=1;
        String msg= "la inceput litera mare apoi litere mici";

        if(!validName(firstname))
        {
            vf=0;
            lb1.setText(msg);
        }

        if(!validName(lastname))
        {
            vf=0;
            lb2.setText(msg);
        }

        if(email.equals(""))
        {
            vf=0;
            lb3.setText("field gol");
        }
        else
        {
            Pattern p = Pattern.compile("^(([^<>()\\[\\]\\\\.,;:\\s@\"]+(\\.[^<>()\\[\\]\\\\.,;:\\s@\"]+)*)|(\".+\"))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$");
            Matcher m = p.matcher(email);
            boolean b = m.matches();

            if(!b)
            {
                vf=0;
                lb3.setText("mail invalid");
                System.out.println("njsdmkal");
            }
            else
                if(srvU.findByEmail(email)!=null)
                {
                    vf=0;
                    lb3.setText("este deja acest mail");
                }
        }

        if(!validUsername(username))
        {
            vf=0;
            lb4.setText("tb sa fie cifre si litere mari si mici");
        }
        else
        {
            if(srvU.findByUsername(username)!=null)
            {
                vf=0;
                lb4.setText("este deja acest username");
            }
        }

        if(password.length()==0)
        {
            vf=0;
            lb5.setText("parola nu tb sa fie vida");
        }

        if(!password2.equals(password))
        {
            vf=0;
            lb6.setText("tb sa fie egal cu password");
        }

        if(vf==0)
            return;

        Utilizator ut = new Utilizator(firstname,lastname);
        ut.setEmail(email);
        ut.setUsername(username);
        ut.setPassword(password);



        try
        {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(password.getBytes(),0,password.length());
            String z = new BigInteger(1,md.digest()).toString(16);
            System.out.println(z);
            ut.setPassword(z);
        }
        catch(Exception e)
        {
            System.out.println(e);
            return;
        }

        srvU.addUtilizator(ut);

        creez(ut.getId());
    }

    private void creez(Long id) {
        try {
            Stage stage = (Stage) anchorPane.getScene().getWindow();
            stage.close();
            Stage primaryStage = new Stage();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/sidebar.fxml"));
            Pane root;
            root = loader.load();
            SideBarController sbc = loader.getController();
            sbc.setSrvE(srvE);
            sbc.initial(id, srvU, srvP, srvM, srvC);

            //UserController ctrl=loader.getController();
            //ctrl.setSrv(srvU,srvP,srvM,srvC);

            primaryStage.setScene(new Scene(root));
            primaryStage.setTitle("Social Network");
            primaryStage.show();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    private boolean validUsername(String username) {
        if(username.equals(""))
            return false;
        for(int i=0;i<username.length();i++)
        {
            char ch=username.charAt(i);
            if(Character.isDigit(ch)==false&&(Character.isLowerCase(ch)==false&&Character.isUpperCase(ch)==false))
                return false;
        }
        return true;
    }

    private boolean validName(String name) {

        if(name.length()==0)
            return false;

        char ch=name.charAt(0);
        if(Character.isUpperCase(ch)==false)
            return false;

        for(int i=1;i<name.length();i++)
        {
            ch=name.charAt(i);
            if(Character.isLowerCase(ch)==false)
                return false;
        }

        return true;
    }

    public void initial(UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {

        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
    }

    public void setSrvE(EvenimenteService srvE) {
        this.srvE = srvE;
    }
}
