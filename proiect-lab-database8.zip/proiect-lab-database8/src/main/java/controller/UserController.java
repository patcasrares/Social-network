package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import socialnetwork.MessageAlert;
import socialnetwork.domain.Prietenie;
import socialnetwork.domain.Tuple;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.util.*;

public class UserController extends Control {

    @FXML
    private VBox boxUser;
    private ArrayList<String> lstImagini;

    @Override
    public void restart()
    {
        U = srvU.findOne(U.getId());
        creezViewNou();
    }

    @FXML
    private Pagination pagination;

    @FXML
    private BorderPane bp;

    private UtilizatorService srvU=null;
    private Utilizator U = null;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;

    private CereriUserController cer=null;
    private Stage cerere_stage;
    private AddFriendController add_friend;
    private Stage add_stage;
    private SideBarController sbc;

    public void setSrvU(UtilizatorService srvU)
    {
        System.out.println(242343);
        this.srvU = srvU;
    }

    public void setU(Utilizator U)
    {
        this.U=U;
        modelGrade.setAll(U.getFriends());
        if(cer!=null)
            cer.setUser(U);
    }


    ObservableList<Utilizator> modelGrade = FXCollections.observableArrayList();



    private int count = 5;

    //@FXML
    //TextField textFieldId;

    @FXML
    public void initialize() {

       // textFieldId.textProperty().addListener(c -> handleUser());
        if(U!=null) {
            for (Utilizator f : U.getFriends()) {
                Image image = new Image(getClass().getResourceAsStream("/images/Lx.png"));
                ImageView img = new ImageView(image);
                img.setFitHeight(20);
                img.setFitWidth(20);
                f.getDelBtn().setGraphic(img);
                f.getDelBtn().setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        stergere(f);
                    }
                });

                Utilizator g = f;
                f.getRaportBtn().setOnAction(new EventHandler<ActionEvent>() {
                    @Override
                    public void handle(ActionEvent event) {
                        openRaport(g);
                    }
                });
            }

            //super.creezTabel(pagination,U.getFriends(),count,modelGrade);
            //modelGrade.setAll(U.getFriends());

            creezViewNou();
        }
    }

    private void creezViewNou() {
        int nrP = U.getFriends().size()/count;
        if(U.getFriends().size()% count > 0)
            nrP++;
        pagination.setPageCount(nrP);
        pagination.setPageFactory(x->{
            int lst = x * count;
            int ldr = lst + count - 1;
            ldr = Math.min(ldr,U.getFriends().size()-1);
            List<Utilizator> lstAux = new ArrayList<>();

            for(int i= lst;i<=ldr;i++) {
                //int pz = i+x+2;
                //pz = pz%lstImagini.size();
                //System.out.println("IMAGINE" + pz);
                lstAux.add(U.getFriends().get(i));
            }
            creezListaUser(lstAux);
            return new BorderPane();
        });
    }

    private void creezListaUser(List<Utilizator> friends) {
        boxUser.getChildren().clear();
        Collections.shuffle(lstImagini);
        int cnt = 0;
        for(Utilizator ut:friends)
        {
            viewFriend(ut,cnt);
            cnt++;
            if(cnt >= lstImagini.size())
                cnt = 0;
        }
    }

    private void viewFriend(Utilizator ut,int pz) {
        try
        {
            try {
                System.out.println("Imagine Rares "+pz);
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/view/Friend.fxml"));
                Pane root = loader.load();

                boxUser.getChildren().add(root);

                Friend fr = loader.getController();
                fr.setText(ut.getUsername() );

                fr.getRem().setOnAction(x-> {stergere(ut);});

                fr.getIstoric().setOnAction(x->{openRaport(ut);});


                Image image = new Image(getClass().getResourceAsStream(lstImagini.get(pz)));
                ImageView img=new ImageView(image);
                img.setFitHeight(53);
                img.setFitWidth(53);

                fr.getProfil().getChildren().add(img);


            }
            catch(Exception e){

            }
        }
        catch(Exception e)
        {

        }
    }

    private void openRaport(Utilizator ut) {
        sbc.openRaport(ut);
       /* Parent root = null;
        RaportController rap = null;
        try
        {
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource("/view/Raport.fxml"));

            root = loader.load();
            rap = loader.getController();
            //cc.parinte(this);

            //cc.setDestinari(utilizatori);
            rap.initial(U, srvU, srvP, srvM, srvC);

            rap.filter(ut);


        }
        catch(Exception e)
        {
            System.out.println(e);
            System.out.println("nu merge");
            System.out.println(e.getStackTrace());
        }
        bp.setCenter(root);*/
    }


    private void stergere(Utilizator selected) {
        U.removeFriend(selected);
        Prietenie p = new Prietenie();
        p.setId(new Tuple<Long, Long>(U.getId(), selected.getId()));
        srvP.removePrietenie(p);
        creezViewNou();
        MessageAlert.showMessage(null, Alert.AlertType.INFORMATION, "deletion", "prietenia a fost stearsa");

    }



    public void setSrvP(PrietenieService srvP) {
        this.srvP = srvP;
    }



    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U=U;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
        imaginiProfil();
        initialize();
    }

    private void imaginiProfil() {
         lstImagini =
                new ArrayList<String>( Arrays.asList(
                        "/images/cats.png",
                        "/images/lion_96px.png",
                        "/images/bear_96px.png",
                        "/images/panda_96px.png",
                        "/images/cat_profile_128px.png"
                        ) );
    }

    @Override
    public void parinte(SideBarController sbc) {
        this.sbc = sbc;
    }
}
