package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class ChatBox {
    @FXML
    private Label label;

    @FXML
    private Button button;

    public void setText(String str)
    {
        label.setText(str);
    }

    public Button getButton()
    {
        return button;
    }

}
