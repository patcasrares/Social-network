package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Pagination;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import socialnetwork.domain.Cerere;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.util.List;

public class CereriUserPrimiteController extends Control {


    @Override
    public void restart()
    {
        if(U==null)
            return;
        System.out.println("restart");

        int nrU = 0;
        if(getStart()==false)
            nrU = getPageDTO().getNrCereriPrimite();
        else
            nrU = srvC.nrCereri(U.getId(),1);
        int cntP= nrU / count;
        if( nrU%count>0)
            cntP++;
        pagination.setPageCount(cntP);
        pagination.setPageFactory((index)->{
            if(getStart()==false) {
                List<Cerere> lstU = srvC.cereri(U.getId(), index, count, 1);
                addButoane(lstU);
                modelCereri.setAll(lstU);
                System.out.println("e gresit omule");
            }
            setStart(false);
            return new AnchorPane();
        });


        /*if(U!=null){
            List<Cerere> listCereri = srvC.cereri_primite(U.getId());
            addButoane(listCereri);

            super.creezTabel(pagination,listCereri,count,modelCereri);
            //modelCereri.setAll(listCereri);
        }*/
    }

    @FXML
    private Pagination pagination;

    private Utilizator U=null;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private MessageService srvM;
    private CerereService srvC;
    ObservableList<Cerere> modelCereri = FXCollections.observableArrayList();
    private int count=5;

    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U=U;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
        System.out.println("dshuajiok");
        if(getPageDTO() == null)
            System.out.println("hjwioskquhygtfdctrfyuhhygtfrethyuojyhgt5rf4e35r6thyuj");
        System.out.println(getPageDTO());
        initializez();
    }

    //private TableView cereri;

    @FXML
    TableColumn<Cerere, Long> Sender;
    @FXML
    TableColumn<Cerere, String> Date;
    @FXML
    TableColumn<Cerere, Button> acceptAction;
    @FXML
    TableColumn<Cerere, Button> rejectAction;

    @FXML
    TableView<Cerere> cereri;

    public void initializez()
    {
        this.Sender.setCellValueFactory(new PropertyValueFactory<Cerere , Long>("Sender"));
        this.Date.setCellValueFactory(new PropertyValueFactory<Cerere , String>("Date"));
        this.acceptAction.setCellValueFactory(new PropertyValueFactory<Cerere , Button>("AcceptButton"));
        this.rejectAction.setCellValueFactory(new PropertyValueFactory<Cerere , Button>("RejectButton"));

        cereri.setItems(modelCereri);
        System.out.println(getPageDTO());
        //if(getPageDTO()==null)
            System.out.println("fvthyujiknhjgfdrfthujogtfredrthyugtfredrthyunjhybgtrfeftgh");
        List<Cerere> lst = getPageDTO().getCereriPrimite();
        System.out.println(lst);
        List<Cerere> primite = getPageDTO().getCereriPrimite();
        addButoane(primite);
        modelCereri.setAll(primite);
       // System.out.println();

        /*if(U!=null){
            List<Cerere> listCereri = srvC.cereri_primite(U.getId());
            addButoane(listCereri);

            super.creezTabel(pagination,listCereri,count,modelCereri);
            //modelCereri.setAll(listCereri);
        }*/
        restart();

    }

    private void addButoane(List<Cerere> listCereri) {
        for (Cerere c : listCereri) {
            c.getAcceptButton().setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    srvC.accepta(c.getRecv(), c.getId());
                    List<Cerere> lst = srvC.cereri_primite(U.getId());
                    addButoane(lst);
                    creezTabel(pagination,lst,count,modelCereri);
                    updateFerestre();
                    //modelCereri.setAll(srvC.cereri_primite(U.getId()));
                }
            });
            c.getRejectButton().setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    srvC.refuza(c.getRecv(), c.getId());

                    List<Cerere> lst = srvC.cereri_primite(U.getId());
                    addButoane(lst);
                    creezTabel(pagination,lst,count,modelCereri);
                }
            });
        }
    }


    public void setSrv(UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.srvU=srvU;
        this.srvP=srvP;
        this.srvM=srvM;
        this.srvC=srvC;

       // initialize();
    }

    public void setUser(Utilizator U) {
        this.U=U;
        update();
    }

    private void update() {
        if(U==null)
            return;
        modelCereri.setAll(srvC.cereri_primite(U.getId()));

    }
}
