package controller;

import com.sun.javafx.fxml.builder.ProxyBuilder;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import socialnetwork.domain.Cerere;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.CerereService;
import socialnetwork.service.MessageService;
import socialnetwork.service.PrietenieService;
import socialnetwork.service.UtilizatorService;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class CreateNewMessage extends Control{


    @FXML
    private VBox boxUser;

    private int count = 4;
    @FXML
    private Pagination pagination;

    private ConversatiiController controllerConv;
    private  Utilizator U  ;
    private MessageService srvM;
    private UtilizatorService srvU;
    private PrietenieService srvP;
    private CerereService srvC;

    private List<Utilizator> users_for_new_message = new ArrayList<>();
    private List<Long> id_for_new_message = new ArrayList<>();

    ObservableList<Utilizator> modelUser = FXCollections.observableArrayList();

    @FXML
    TextField First;
    @FXML
    TextField Last;


    private boolean chatPlin = false;
    private List<String> lstImagini;

    private void add_butoane(List<Utilizator> lst) {
        for(Utilizator f:lst)
        {

            chatPlin = true;
            Image image = new Image(getClass().getResourceAsStream("/images/add.png"));
            if(id_for_new_message.contains(f.getId()))
                image = new Image(getClass().getResourceAsStream("/images/LX.png"));
            ImageView img=new ImageView(image);
            img.setFitHeight(20);
            img.setFitWidth(20);
            f.getAddBtn().setGraphic(img);
            f.getAddBtn().setOnAction(new EventHandler<ActionEvent>() {
                @Override
                public void handle(ActionEvent event) {
                    if(!id_for_new_message.contains(f.getId()))
                    {
                        id_for_new_message.add(f.getId());
                        users_for_new_message.add(f);
                        Image image = new Image(getClass().getResourceAsStream("/images/LX.png"));
                        ImageView img=new ImageView(image);
                        img.setFitHeight(20);
                        img.setFitWidth(20);
                        f.getAddBtn().setGraphic(img);
                    }
                    else{
                        id_for_new_message.remove(f.getId());
                        users_for_new_message.remove(f);
                        Image image = new Image(getClass().getResourceAsStream("/images/add.png"));
                        ImageView img=new ImageView(image);
                        img.setFitHeight(20);
                        img.setFitWidth(20);
                        f.getAddBtn().setGraphic(img);
                    }

                }
            });
        }
    }


    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U=U;
        this.srvU = srvU;
        this.srvP = srvP;
        this.srvM = srvM;
        this.srvC = srvC;
        creezImagini();


        int nrU = srvU.nrUtilizatori();
        int cntP= nrU / count;
        if( nrU%count>0)
            cntP++;
        pagination.setPageCount(cntP);
        pagination.setPageFactory((index)->{
            List<Utilizator> lstU = srvU.getAll(index,count);
            creezLista(lstU);

            return new AnchorPane();
        });



        First.textProperty().addListener(c -> handlePrieten());
        //Last.textProperty().addListener(c -> handlePrieten());
    }

    private void creezLista(List<Utilizator> lstU) {
        boxUser.getChildren().clear();
        int pz =0;
        Collections.shuffle(lstImagini);
        for(Utilizator ut:lstU)
        {

            try
            {
                pz++;

                if(pz==lstImagini.size()) {
                    pz = 0;
                }
                FXMLLoader loader=new FXMLLoader();
                loader.setLocation(getClass().getResource("/view/ChatUser.fxml"));
                Pane root = loader.load();
                ChatUser cc = loader.getController();

                System.out.println(ut);
                cc.setText(ut.getUsername());

                boxUser.getChildren().add(root);

                Image image = new Image(getClass().getResourceAsStream(lstImagini.get(pz)));
                ImageView img=new ImageView(image);
                img.setFitHeight(53);
                img.setFitWidth(53);

                cc.getProfil().getChildren().add(img);

                if(users_for_new_message.contains(ut))
                    cc.getButon().setText("Scoate din grup");
                else
                    cc.getButon().setText("Adauga in grup");
                cc.getButon().setOnAction(x->{
                    if(users_for_new_message.contains(ut)) {
                        cc.getButon().setText("Adauga in grup");
                        users_for_new_message.remove(ut);
                    }
                    else {
                        cc.getButon().setText("Scoate din grup");
                        users_for_new_message.add(ut);
                    }
                });

                if(U.getId().equals(ut.getId()))
                {
                    cc.getButon().setText("Your username");
                    cc.getButon().setOnAction(x->{

                    });
                    cc.getButon().setStyle( "-fx-background-color: #4d4dff");
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    private void handlePrieten() {
        int nrU = srvU.nrUtilizatori(First.getText());
        int cntP= nrU / count;
        if( nrU%count>0)
            cntP++;
        pagination.setPageCount(cntP);
        pagination.setPageFactory((index)->{
            List<Utilizator> lstU = srvU.getAll(index,count,First.getText());
            creezLista(lstU);
            return new AnchorPane();
        });

    }

    public void setParent(ConversatiiController c){
        controllerConv = c;
    }

    public void createConversation(ActionEvent actionEvent) {
        if(users_for_new_message.isEmpty())
            return;
        controllerConv.showChat(U.getId(), users_for_new_message);
    }

    private void creezImagini() {
        lstImagini =
                new ArrayList<String>( Arrays.asList(
                        "/images/cats.png",
                        "/images/lion_96px.png",
                        "/images/bear_96px.png",
                        "/images/panda_96px.png",
                        "/images/cat_profile_128px.png"
                ) );
    }
}
