package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import socialnetwork.domain.Eveniment;
import socialnetwork.domain.Utilizator;
import socialnetwork.service.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class AllController extends Control {


    private  Utilizator U ;
    @FXML
    private VBox totul;
    private UtilizatorService srvU;
    private MessageService srvM;
    private CerereService srvC;
    private PrietenieService srvP;
    private EvenimenteService srvE;
    private Map<String, Parent> mpFerestre;

    @Override
    public void initial(Utilizator U, UtilizatorService srvU, PrietenieService srvP, MessageService srvM, CerereService srvC) {
        this.U = U;
        this.srvU = srvU;
        this.srvM = srvM;
        this.srvC = srvC;
        this.srvP = srvP;

        //adaug();
    }

    @Override
    public void setSrvEvent(EvenimenteService srv)
    {
        this.srvE = srv;
        //adaug();
    }

    @Override
    public void setFerestre(Map<String, Parent> mpFerestre)
    {
        this.mpFerestre = mpFerestre;
        adaug();
    }

    private void loadPage(String s) {
        Parent root = mpFerestre.get(s);
        System.out.println(root);
        /*try
        {
            FXMLLoader loader=new FXMLLoader();
            loader.setLocation(getClass().getResource(s));

            root = loader.load();
            Control cc = loader.getController();
            //cc.parinte(this);

            cc.initial(U,srvU,srvP,srvM,srvC);

        }
        catch(Exception e)
        {
            System.out.println(e);
            System.out.println("nu merge");
            System.out.println(e.getStackTrace());
        }*/
        totul.getChildren().add(root);
    }

    private void adaug() {
        totul.getChildren().add(new Label(U.getFirstName()+" "+U.getLastName()));
        adaugareNotificari();
        totul.getChildren().add(new Label("Friends"));
        Label b;
        b=new Label("                      PRIETENI                  ");
        b.setFont(Font.font(16));
        b.setStyle(("-fx-background-color:FF6633"));
        totul.getChildren().addAll(b);

        loadPage("/view/UserView.fxml");

        b=new Label("                      ADAUGARE PRIETENI                  ");
        b.setFont(Font.font(16));
        b.setStyle(("-fx-background-color:FF6633"));
        totul.getChildren().addAll(b);

        loadPage("/view/AdaugFriend.fxml");

        b=new Label("                      CERERI TRIMISE                  ");
        b.setFont(Font.font(16));
        b.setStyle(("-fx-background-color:FF6633"));
        totul.getChildren().addAll(b);

        loadPage("/view/CereriUseriTrimise.fxml");

        b=new Label("                      CERERI PRIMITE                  ");
        b.setFont(Font.font(16));
        b.setStyle(("-fx-background-color:FF6633"));
        totul.getChildren().addAll(b);

        loadPage("/view/CereriUserPrimite.fxml");

        b=new Label("                      CONVERSATII                  ");
        b.setFont(Font.font(16));
        b.setStyle(("-fx-background-color:FF6633"));
        totul.getChildren().addAll(b);
        loadPage("/view/Conversatii.fxml");

    }

    private void adaugareNotificari() {
        Set<Long> abonari = srvE.getAbonari(U.getId());
        List<Eveniment> lstEvent = srvE.getAll()
                .stream()
                .filter(ev->{
                    System.out.println("pink");
                    if(!abonari.contains(ev.getId()))
                        return false;
                    if(LocalDateTime.now().compareTo(ev.getDate())>=0)
                        return false;
                    return true;
                })
                .collect(Collectors.toList());
        for(Eveniment ev:lstEvent)
        {
            Label eveniment = new Label("Evenimentul: "+ev.getDescriere()+" va incepe la ora 20:30");
            eveniment.setFont(Font.font(16));
            eveniment.setStyle("-fx-background-color: pink");
            totul.getChildren().add(eveniment);
        }
    }
}
